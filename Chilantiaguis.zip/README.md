# CHILANTIAGUIS · CDMX · MVP del Chilangatón 2026

**Tecnologías:** Python + Flask, SQLite3, HTML/Jinja2, Tailwind CSS compilado, CSS propio, JavaScript y Leaflet / OpenStreetMap.

Mapa público de **tianguis, mercados públicos, tiendas de barrio y pequeños negocios**, con filtros por nombre/producto, tipo, alcaldía, categoría, día y remates activos. Los comerciantes pueden registrarse para crear comercios o puestos, agregar productos y programar descuentos con fecha y hora. **Quienes compran no necesitan cuenta y NO hay chat, pagos ni pedidos online.**

**Vista inmediata del diseño:** abre `vista_previa.html` con doble clic para ver la nueva portada sin instalar nada. Es una vista estática; el mapa y los filtros requieren Flask.

## 1. Iniciar en Windows con VS Code (PowerShell)

Descomprime el ZIP `Chilantiaguis_CDMX_v2.zip`, abre la carpeta `Chilantiaguis` en VS Code y abre Terminal > Nueva terminal. Ya dentro de `Chilantiaguis`, ejecuta **uno por uno**:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
.\.venv\Scripts\python.exe -m flask --app app demo
.\.venv\Scripts\python.exe -m flask --app app run --debug
```

Abre http://127.0.0.1:5000. Si el archivo `.env` ya existe, puedes omitir `Copy-Item`.

**Comerciante de prueba:** `vendedor@demo.local` / `Demo12345!`. Solo para desarrollo, no publiques estas credenciales en un servidor real.

**Importante:** el comando `demo` carga seis lugares **inventados y etiquetados DEMO** para mostrar los cuatro tipos desde el primer minuto. Las ubicaciones no corresponden a esos negocios reales. Para una BD sin ejemplos no ejecutes `demo`.

## 2. Traer ubicaciones reales de la SEDECO (necesita internet)

Primero inicia Flask una vez para crear `instance/chilantiaguis.sqlite3`. Detén el servidor con `Ctrl + C` y ejecuta:

```powershell
.\.venv\Scripts\python.exe scripts\importar_cdmx.py
```

Ese importador busca en el **catálogo público CKAN** del Portal de Datos Abiertos de CDMX y descarga los recursos GeoJSON de:

- https://datos.cdmx.gob.mx/dataset/tianguis-de-la-ciudad-de-mexico
- https://datos.cdmx.gob.mx/dataset/mercados-publicos

Si el portal se encuentra lento/no responde o ha cambiado sus endpoints, descarga los archivos **GeoJSON** manualmente y ejecuta:

```powershell
.\.venv\Scripts\python.exe scripts\importar_cdmx.py --tianguis "C:\ruta\tianguis.geojson" --mercados "C:\ruta\mercados.geojson"
```

Después vuelve a ejecutar el comando del servidor. La importación evita registros idénticos por tipo + nombre + coordenada aproximada. **Los registros oficiales solo garantizan lo que efectivamente traiga el conjunto de datos: no se inventan categorías, horarios, productos, descuentos ni nombres propios faltantes.** Cuando falta el nombre oficial se utiliza una etiqueta genérica como «Tianguis registrado · [referencia]».

El portal registra GeoJSON de tianguis actualizado en sus recursos el **9 de enero de 2024**, y mercados públicos GeoJSON en **febrero de 2023** (según ficha del recurso consultada). La fecha de actualización de la página general del catálogo no sustituye la fecha del archivo específico. Comprueben ubicaciones antes de presentarlas como vigentes.

Para **tiendas y pequeños negocios**, el comerciante puede registrar su propia ubicación desde su panel. Para cargar más negocios reales a gran escala, una siguiente integración puede usar la **API DENUE del INEGI**, que necesita token y clasificación correcta por actividad:
https://www.inegi.org.mx/servicios/api-denue/

La plataforma muestra **todos los resultados que coincidan en la base local**, no garantiza que ya estén inventariados todos los pequeños negocios de las 16 alcaldías.

## 3. Cambiar de BarrioConecta a Chilantiaguis SIN perder registros

Si ya tienes una base local de la versión antigua, puedes **copiar** (no mover) la base `Barrioconecta/instance/barrioconecta.sqlite3` como `Chilantiaguis/instance/chilantiaguis.sqlite3` ANTES de iniciar la nueva aplicación. De esa forma se conservan vendedores, puestos, productos y remates. No copies el código Python viejo. Los registros de mensajería antiguos quedan en las tablas antiguas, pero Chilantiaguis no ofrece rutas ni interfaz para utilizarlos. Respalda el archivo antes de empezar; para eliminar esas tablas y datos necesitarías una migración explícita posterior.

La base nueva usa `instance/chilantiaguis.sqlite3` y nunca modifica automáticamente la base vieja.

## 4. Estructura

```text
Chilantiaguis/
  app.py                    Servidor Flask y API de filtros
  schema.sql                Tablas de comerciantes, comercios, horarios, puestos, productos, remates
  seed.py                   Seis ejemplos etiquetados DEMO
  requirements.txt          Dependencias (incluye tzdata para Windows)
  templates/                Portada, explorador, fichas, formularios y panel
  static/css/style.css      Rosa mexicano, carteles, patrones y adaptación responsive
  static/js/mapa.js         Leaflet, filtros y resultados
  scripts/importar_cdmx.py Descarga e importación del catálogo oficial CKAN
  scripts/importar_geojson.py  Importador para un archivo GeoJSON local
  instance/                 Base creada por Flask (no enviar al repositorio)
```

## 5. Cómo se usan los filtros

`/explorar?tipo=tianguis` muestra únicamente tianguis. `/explorar?remates=1` muestra comercios con descuentos vigentes. El navegador consulta `GET /api/comercios` al cambiar filtros; Flask consulta SQLite y devuelve un JSON de las ubicaciones coincidentes. Los campos vacíos no filtran.

Importante: el filtro por categoría solo muestra lugares con **productos categorizados por vendedores**, y el filtro de día solo lugares con **horarios publicados**. Un registro oficial sin esos campos no puede satisfacer esos filtros hasta que un comerciante complete su ficha. Así evitamos inventar horarios o categorías.

## 6. Notas técnicas

- OpenStreetMap aporta las teselas del mapa, Leaflet la interfaz y SQLite las ubicaciones; ningún mapa por sí solo tiene la lista completa de comercios del Reto 1.
- El mapa requiere conexión a internet. No requiere API key ni activación de facturación.
- Se muestra atribución de OpenStreetMap. Consulta su política de uso si crece el tráfico: https://operations.osmfoundation.org/policies/tiles/
- Las cuentas son **solo para comerciantes**. Los visitantes pueden explorar portada, mapa y fichas sin autenticarse.
- No hay rutas `/mensajes`, `/chat` ni tablas nuevas de mensajes. Los horarios y descuentos se calculan en la zona horaria `America/Mexico_City`.
- `--debug` se utiliza solo en local. Para producción faltan HTTPS, limitación de intentos de inicio de sesión, verificación/moderación de perfiles, política de privacidad y un servicio de mapas escalable.
