PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    rol TEXT NOT NULL CHECK (rol = 'comerciante'),
    creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS comercios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    propietario_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
    nombre TEXT NOT NULL,
    tipo TEXT NOT NULL CHECK (tipo IN ('tianguis','mercado','tienda','negocio')),
    descripcion TEXT NOT NULL DEFAULT '',
    alcaldia TEXT NOT NULL,
    colonia TEXT NOT NULL DEFAULT '',
    direccion TEXT NOT NULL,
    lat REAL NOT NULL CHECK (lat BETWEEN 19.0 AND 20.0),
    lng REAL NOT NULL CHECK (lng BETWEEN -100.0 AND -98.0),
    origen TEXT NOT NULL DEFAULT 'comerciante' CHECK (origen IN ('demo','comerciante','datos_abiertos')),
    verificado INTEGER NOT NULL DEFAULT 0 CHECK (verificado IN (0,1)),
    creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS horarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    comercio_id INTEGER NOT NULL REFERENCES comercios(id) ON DELETE CASCADE,
    dia INTEGER NOT NULL CHECK (dia BETWEEN 0 AND 6),
    inicio TEXT NOT NULL,
    fin TEXT NOT NULL,
    UNIQUE(comercio_id, dia)
);

CREATE TABLE IF NOT EXISTS puestos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    comercio_id INTEGER NOT NULL REFERENCES comercios(id) ON DELETE CASCADE,
    vendedor_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    nombre TEXT NOT NULL,
    descripcion TEXT NOT NULL DEFAULT '',
    referencia TEXT NOT NULL DEFAULT '',
    imagen_url TEXT NOT NULL DEFAULT '',
    creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categorias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS productos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    puesto_id INTEGER NOT NULL REFERENCES puestos(id) ON DELETE CASCADE,
    categoria_id INTEGER NOT NULL REFERENCES categorias(id),
    nombre TEXT NOT NULL,
    descripcion TEXT NOT NULL DEFAULT '',
    precio_centavos INTEGER NOT NULL CHECK (precio_centavos > 0),
    imagen_url TEXT NOT NULL DEFAULT '',
    disponible INTEGER NOT NULL DEFAULT 1 CHECK (disponible IN (0,1)),
    creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS remates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id INTEGER NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
    descuento INTEGER NOT NULL CHECK (descuento BETWEEN 1 AND 90),
    inicio TEXT NOT NULL,
    fin TEXT NOT NULL,
    creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (fin > inicio)
);

CREATE INDEX IF NOT EXISTS idx_comercios_tipo_alcaldia ON comercios(tipo, alcaldia);
CREATE INDEX IF NOT EXISTS idx_horarios_dia ON horarios(dia);
CREATE INDEX IF NOT EXISTS idx_puestos_comercio ON puestos(comercio_id);
CREATE INDEX IF NOT EXISTS idx_productos_puesto ON productos(puesto_id);
CREATE INDEX IF NOT EXISTS idx_remates_vigencia ON remates(inicio, fin);

