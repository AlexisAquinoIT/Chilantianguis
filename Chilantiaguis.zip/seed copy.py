"""Información totalmente ficticia de demostración. NO representa un directorio verificado."""
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from werkzeug.security import generate_password_hash


DEMO_COMERCIOS = [
    ("Tianguis de muestra · Centro", "tianguis", "Frutas, verduras, ropa y comida. Ejemplo ficticio para el hackatón.",
     "Cuauhtémoc", "Centro", "Ubicación aproximada de demostración, Centro Histórico", 19.4320, -99.1332, [1, 4, 6], "08:00", "17:00"),
    ("Mercado público de muestra · Roma", "mercado", "Comercio tradicional: alimentos y productos cotidianos. Ejemplo ficticio.",
     "Cuauhtémoc", "Roma Norte", "Ubicación aproximada de demostración, Roma Norte", 19.4185, -99.1605, [0, 1, 2, 3, 4, 5], "08:00", "19:00"),
    ("Abarrotes de muestra · Iztapalapa", "tienda", "Tienda de barrio ficticia con productos básicos.",
     "Iztapalapa", "Centro", "Ubicación aproximada de demostración, Iztapalapa", 19.3579, -99.0922, list(range(7)), "07:00", "21:00"),
    ("Panadería de muestra · Coyoacán", "negocio", "Pequeño negocio ficticio con pan artesanal.",
     "Coyoacán", "Del Carmen", "Ubicación aproximada de demostración, Coyoacán", 19.3495, -99.1625, [0, 1, 2, 3, 4, 5], "08:00", "20:00"),
    ("Tianguis de muestra · Xochimilco", "tianguis", "Flores, verduras y artesanías. Ejemplo ficticio.",
     "Xochimilco", "Centro", "Ubicación aproximada de demostración, Xochimilco", 19.2546, -99.1036, [2, 5], "08:00", "16:00"),
    ("Mercado público de muestra · GAM", "mercado", "Alimentos, flores y artículos de uso diario. Ejemplo ficticio.",
     "Gustavo A. Madero", "Lindavista", "Ubicación aproximada de demostración, Lindavista", 19.4945, -99.1288, list(range(7)), "08:00", "18:00"),
]


def create_demo(db):
    existing = db.execute("SELECT 1 FROM comercios WHERE origen='demo' LIMIT 1").fetchone()
    if existing:
        return "La demostración ya estaba cargada; no se duplicaron los comercios."

    def usuario(nombre, email, password, rol):
        db.execute("INSERT OR IGNORE INTO usuarios(nombre,email,password_hash,rol) VALUES(?,?,?,?)",
                   (nombre, email, generate_password_hash(password), rol))
        return db.execute("SELECT id FROM usuarios WHERE email=?", (email,)).fetchone()[0]

    with db:
        seller = usuario("Comerciante de prueba", "vendedor@demo.local", "Demo12345!", "comerciante")
        for i, item in enumerate(DEMO_COMERCIOS):
            nombre, tipo, desc, alc, colonia, dir_, lat, lng, dias, inicio, fin = item
            comercio = db.execute("""INSERT INTO comercios(propietario_id,nombre,tipo,descripcion,alcaldia,colonia,direccion,lat,lng,origen)
                 VALUES(?,?,?,?,?,?,?,?,?,'demo')""", (seller, nombre, tipo, desc, alc, colonia, dir_, lat, lng)).lastrowid
            db.executemany("INSERT INTO horarios(comercio_id,dia,inicio,fin) VALUES(?,?,?,?)",
                           [(comercio, dia, inicio, fin) for dia in dias])
            puesto = db.execute("INSERT INTO puestos(comercio_id,vendedor_id,nombre,descripcion,referencia) VALUES(?,?,?,?,?)",
                                (comercio, seller, ["Verduras Lupita · DEMO", "Comida Doña Sol · DEMO", "Abarrotes El Centro · DEMO",
                                    "Pan de barrio · DEMO", "Flores y plantas · DEMO", "Artículos del hogar · DEMO"][i],
                                 "Catálogo de ejemplo; productos y precios ficticios.", "Sector de muestra, no es un puesto real.")).lastrowid
            catalog = [("Jitomate por kg", "Frutas y verduras", 3000),
                       ("Comida corrida", "Comida preparada", 9500),
                       ("Arroz 1 kg", "Abarrotes", 3200),
                       ("Concha artesanal", "Comida preparada", 1800),
                       ("Ramo de flores", "Flores y plantas", 12000),
                       ("Juego de recipientes", "Hogar", 8500)]
            product_name, catname, cents = catalog[i]
            cat = db.execute("SELECT id FROM categorias WHERE nombre=?", (catname,)).fetchone()[0]
            product = db.execute("INSERT INTO productos(puesto_id,categoria_id,nombre,descripcion,precio_centavos) VALUES(?,?,?,?,?)",
                                 (puesto, cat, product_name, "Precio demostrativo; confirmar con el comerciante.", cents)).lastrowid
            # Se crean remates presentes y futuros para enseñar estados y filtros.
            if i < 2:
                now = datetime.now(ZoneInfo("America/Mexico_City"))
                begin = now - timedelta(minutes=30) if i == 0 else now + timedelta(hours=2)
                end = now + timedelta(hours=3) if i == 0 else now + timedelta(hours=5)
                db.execute("INSERT INTO remates(producto_id,descuento,inicio,fin) VALUES(?,?,?,?)",
                           (product, 30 if i == 0 else 20, begin.strftime("%Y-%m-%dT%H:%M"), end.strftime("%Y-%m-%dT%H:%M")))
    return "6 comercios y cuentas de demostración creados. Datos ficticios, no verificados."
