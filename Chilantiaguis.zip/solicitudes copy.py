"""Extensión de Chilantiaguis: asociación responsable y solicitudes de tianguis.
Para prototipo: NO recibir archivos INE/CURP en este servidor de desarrollo.
"""
import os
import re
import sqlite3
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, session, current_app

bp = Blueprint('solicitudes', __name__)

def migrar(con):
    columnas = {r[1] for r in con.execute('PRAGMA table_info(comercios)')}
    if 'asociacion_responsable' not in columnas:
        con.execute('ALTER TABLE comercios ADD COLUMN asociacion_responsable TEXT')
    con.execute('''CREATE TABLE IF NOT EXISTS solicitudes_tianguis (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre_tianguis TEXT NOT NULL,
      alcaldia TEXT NOT NULL,
      colonia TEXT NOT NULL,
      direccion TEXT NOT NULL,
      lider_nombre TEXT NOT NULL,
      lider_correo TEXT NOT NULL,
      lider_telefono TEXT NOT NULL,
      asociacion TEXT NOT NULL,
      figura_legal TEXT NOT NULL,
      razon_social TEXT NOT NULL,
      rfc_asociacion TEXT NOT NULL,
      representante_legal TEXT NOT NULL,
      folio_documento TEXT NOT NULL DEFAULT '',
      documentos_declarados TEXT NOT NULL,
      privacidad_aceptada INTEGER NOT NULL,
      estado TEXT NOT NULL DEFAULT 'pendiente' CHECK(estado IN ('pendiente','aprobada','rechazada')),
      fecha TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )''')
    con.commit()

@bp.route('/solicitar-tianguis', methods=['GET','POST'])
def solicitar_tianguis():
    if request.method == 'POST':
        campos = ('nombre_tianguis','alcaldia','colonia','direccion','lider_nombre',
                  'lider_correo','lider_telefono','asociacion','figura_legal',
                  'razon_social','rfc_asociacion','representante_legal','folio_documento')
        v = {k:request.form.get(k,'').strip() for k in campos}
        alcaldias = current_app.config['CHILAN_ALCALDIAS']
        if any(not v[k] or len(v[k]) > 180 for k in campos if k != 'folio_documento'):
            flash('Completa todos los campos obligatorios (máximo 180 caracteres).','error')
            return render_template('solicitar_tianguis.html', alcaldias=alcaldias, datos=v),400
        if v['alcaldia'] not in alcaldias or not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',v['lider_correo']):
            abort(400,'Alcaldía o correo inválido')
        if not re.fullmatch(r'[0-9 +()\-]{10,20}',v['lider_telefono']):
            abort(400,'Teléfono inválido')
        if request.form.get('acepto') != 'si':
            flash('Debes aceptar el aviso de privacidad para enviar la solicitud.','error')
            return render_template('solicitar_tianguis.html', alcaldias=alcaldias, datos=v),400
        documentos = ', '.join(request.form.getlist('documentos'))
        permitidos = {'identificacion','curp','acta','representacion','domicilio'}
        docs = set(request.form.getlist('documentos'))
        if not {'identificacion','acta','representacion'}.issubset(docs) or not docs.issubset(permitidos):
            flash('Marca los documentos que puedes presentar: identificación, acta y representación son obligatorios.','error')
            return render_template('solicitar_tianguis.html', alcaldias=alcaldias, datos=v),400
        con = sqlite3.connect(current_app.config['DATABASE'])
        try:
            cur = con.execute('''INSERT INTO solicitudes_tianguis
              (nombre_tianguis,alcaldia,colonia,direccion,lider_nombre,lider_correo,lider_telefono,
              asociacion,figura_legal,razon_social,rfc_asociacion,representante_legal,
              folio_documento,documentos_declarados,privacidad_aceptada)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)''', (*[v[k] for k in campos], ', '.join(sorted(docs))))
            con.commit()
            folio = cur.lastrowid
        finally:
            con.close()
        return render_template('solicitud_enviada.html',folio=folio)
    return render_template('solicitar_tianguis.html',alcaldias=current_app.config['CHILAN_ALCALDIAS'],datos={})

def registrar(app, alcaldias):
    app.config['CHILAN_ALCALDIAS'] = alcaldias
    con = sqlite3.connect(app.config['DATABASE'])
    try: migrar(con)
    finally: con.close()
    app.register_blueprint(bp)
