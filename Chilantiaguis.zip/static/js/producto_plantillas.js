(() => {
  const cat=document.getElementById('categoria_id'), sel=document.getElementById('plantilla');
  const nombre=document.getElementById('nombre'), precio=document.getElementById('precio'), unidad=document.getElementById('unidad');
  function refrescar(){
    const key=cat.selectedOptions[0]?.dataset.nombre;
    const opciones=window.CHILANTIAGUIS_PLANTILLAS[key]||[];
    sel.replaceChildren(new Option('Escribir producto personalizado',''));
    opciones.forEach((item,i)=>sel.add(new Option(`${item[0]} · $${item[1]} / ${item[2]} (ejemplo)`,String(i))));
  }
  cat.addEventListener('change',refrescar);
  sel.addEventListener('change',()=>{
    if(!sel.value) return;
    const item=(window.CHILANTIAGUIS_PLANTILLAS[cat.selectedOptions[0]?.dataset.nombre]||[])[Number(sel.value)];
    if(item){nombre.value=item[0];precio.value=Number(item[1]).toFixed(2);unidad.value=item[2];}
  });
  refrescar();
  const foto=document.getElementById('imagen'),vista=document.getElementById('vista-imagen');
  foto.addEventListener('change',()=>{
    if(!foto.files?.length){vista.style.display='none';return;}
    if(foto.files[0].size>5*1024*1024){alert('Máximo 5 MB.');foto.value='';return;}
    const url=URL.createObjectURL(foto.files[0]);vista.onload=()=>URL.revokeObjectURL(url);
    vista.src=url;vista.style.display='block';
  });
})();
