/* Chilantiaguis: mapa público, sin buscador de texto ni inicio de sesión.
   Datos y filtros vienen de Flask (/api/comercios). */
(() => {
  'use strict';
  const icons = {tianguis: '🧺', mercado: '🏬', tienda: '🥫', negocio: '🪴'};
  const names = {tianguis: 'Tianguis', mercado: 'Mercado público', tienda: 'Tienda de barrio', negocio: 'Pequeño negocio'};
  const dias = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  const $ = id => document.getElementById(id);
  const form = $('filters'), results = $('results'), total = $('total'), status = $('map-engine');
  const centerCDMX = [19.4326, -99.1332];
  const elem = (tag, text, cls) => {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = String(text);
    if (cls) node.className = cls;
    return node;
  };
  const detailUrl = id => `/comercio/${encodeURIComponent(id)}`;
  const validLocation = c => Number.isFinite(Number(c.lat)) && Number.isFinite(Number(c.lng)) &&
    Number(c.lat) >= 18.7 && Number(c.lat) <= 20.2 && Number(c.lng) >= -100.0 && Number(c.lng) <= -98.4;

  function schedule(c) {
    if (!c.horarios_text) return 'Horario no publicado';
    return c.horarios_text.split(';').map(item => {
      const [dia, inicio, fin] = item.split('|');
      return `${dias[Number(dia)] || 'Día'} ${inicio || ''}–${fin || ''}`;
    }).join(' · ');
  }

  if (!window.L) {
    status.textContent = 'No se pudo cargar Leaflet';
    results.append(elem('p', 'Revisa tu conexión a internet y vuelve a cargar la página (Ctrl + F5).', 'source-note'));
    return;
  }

  // draggable permite mover el mapa arrastrando; scrollWheelZoom permite acercar con la rueda.
  const map = L.map('map', {
    dragging: true,
    scrollWheelZoom: true,
    doubleClickZoom: true,
    touchZoom: true,
    zoomControl: true,
    preferCanvas: true,
  }).setView(centerCDMX, 11);

  const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    minZoom: 9,
    maxZoom: 19,
    attribution: '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors'
  }).addTo(map);

  let failedTiles = 0;
  tiles.on('tileerror', () => {
    failedTiles += 1;
    if (failedTiles >= 3) status.textContent = 'Problemas al descargar el mapa · revisa internet';
  });
  tiles.on('tileload', () => {
    if (failedTiles < 3) status.textContent = 'Mapa interactivo · mueve y acerca';
  });

  const markers = L.layerGroup().addTo(map);
  const resizeMap = () => map.invalidateSize({pan: false});
  map.whenReady(() => {
    requestAnimationFrame(resizeMap);
    setTimeout(resizeMap, 300);
  });
  window.addEventListener('resize', resizeMap);

  function createMarker(c) {
    const symbol = elem('div', icons[c.tipo] || '📍', `marker-symbol ${c.tipo}`);
    const marker = L.marker([Number(c.lat), Number(c.lng)], {
      icon: L.divIcon({
        html: symbol.outerHTML,
        className: 'comercio-marker',
        iconSize: [37, 37],
        iconAnchor: [18, 18]
      })
    }).addTo(markers);

    // textContent evita inyectar HTML procedente de vendedores.
    const popup = elem('div', undefined, 'map-pop');
    popup.append(elem('h4', c.nombre));
    popup.append(elem('p', `${names[c.tipo] || 'Comercio'} · ${c.alcaldia}`));
    popup.append(elem('p', `🕒 ${schedule(c)}`));
    popup.append(elem('p', `🧺 ${c.puestos_total || 0} puesto(s) registrado(s)`));
    if (c.puestos_nombres) popup.append(elem('p', `Puestos: ${c.puestos_nombres}`));
    if (c.origen === 'datos_abiertos') popup.append(elem('p', 'Ubicación de datos abiertos; horarios por confirmar si no están publicados.'));
    if (c.origen === 'demo') popup.append(elem('p', 'Ejemplo ficticio · DEMO'));
    const link = elem('a', 'Ver todos los puestos y detalles ↗');
    link.href = detailUrl(c.id);
    popup.append(link);
    marker.bindPopup(popup, {maxWidth: 300});
    return marker;
  }

  function render(items) {
    markers.clearLayers();
    results.replaceChildren();
    const valid = items.filter(validLocation);
    total.textContent = `${valid.length.toLocaleString('es-MX')} lugar${valid.length === 1 ? '' : 'es'}`;
    if (valid.length === 0) {
      results.append(elem('p',
        'No hay lugares cargados con estos filtros. Si aún no tienes datos, ejecuta el comando de demostración o importa los registros de la CDMX.',
        'source-note'));
      return; // No movemos el mapa: sigue disponible para explorarlo.
    }

    const bounds = L.latLngBounds([]);
    for (const c of valid) {
      const latLng = [Number(c.lat), Number(c.lng)];
      const marker = createMarker(c);
      bounds.extend(latLng);
      const card = elem('button', undefined, 'result-card');
      card.type = 'button';
      card.append(elem('h4', `${icons[c.tipo] || '📍'} ${c.nombre}`));
      card.append(elem('p', `${names[c.tipo] || 'Comercio'} · Alcaldía ${c.alcaldia}`));
      if (c.colonia) card.append(elem('p', `Colonia: ${c.colonia}`));
      card.append(elem('p', `🕒 ${schedule(c)}`));
      card.append(elem('p', `🧺 ${c.puestos_total || 0} puesto(s) registrado(s)`));
      if (c.puestos_nombres) card.append(elem('p', `Puestos: ${c.puestos_nombres}`));
      const meta = elem('div', undefined, 'result-meta');
      if (c.remate_activo) meta.append(elem('span', '✹ Remate activo', 'promo'));
      if (c.origen === 'demo') meta.append(elem('span', 'DEMO · Ficticio'));
      else if (c.origen === 'datos_abiertos') meta.append(elem('span', 'Datos abiertos · Por confirmar'));
      else if (!c.verificado) meta.append(elem('span', 'Comerciante · Sin verificar'));
      card.append(meta, elem('span', 'Ubicar en el mapa ↗', 'card-link'));
      card.addEventListener('click', () => {
        map.invalidateSize();
        map.setView(latLng, Math.max(map.getZoom(), 15), {animate: true});
        marker.openPopup();
        if (window.matchMedia('(max-width: 750px)').matches) $('map').scrollIntoView({behavior: 'smooth', block: 'center'});
      });
      results.append(card);
    }
    if (bounds.isValid()) {
      if (valid.length === 1) map.setView(bounds.getCenter(), 15);
      else map.fitBounds(bounds, {padding: [32, 32], maxZoom: 12});
    }
    requestAnimationFrame(resizeMap);
  }

  let activeRequest = null;
  let debounce;
  async function refresh() {
    if (activeRequest) activeRequest.abort();
    activeRequest = new AbortController();
    total.textContent = 'Cargando…';
    const query = new URLSearchParams();
    for (const [key, value] of new FormData(form)) if (value) query.set(key, value);
    try {
      const response = await fetch(`${(typeof window.CHILANTIANGUIS_API === 'string' && window.CHILANTIANGUIS_API.startsWith('/') ? window.CHILANTIANGUIS_API : (typeof window.CHILANTIAGUIS_API === 'string' && window.CHILANTIAGUIS_API.startsWith('/') ? window.CHILANTIAGUIS_API : '/api/comercios'))}?${query}`, {signal: activeRequest.signal});
      if (!response.ok) throw new Error(`Error HTTP ${response.status}`);
      const data = await response.json();
      if (!Array.isArray(data)) throw new Error('La respuesta no es una lista');
      render(data);
      history.replaceState(null, '', location.pathname + (query.size ? `?${query}` : ''));
    } catch (err) {
      if (err.name === 'AbortError') return;
      total.textContent = 'Error';
      results.replaceChildren(elem('p', 'No se pudo cargar el directorio. Comprueba que Flask siga encendido.', 'source-note'));
      console.error('Chilantianguis:', err);
    }
  }

  const initial = new URLSearchParams(location.search);
  for (const [key, val] of initial) {
    const field = form.elements.namedItem(key);
    if (!field || field instanceof RadioNodeList) continue;
    if (field.type === 'checkbox') field.checked = val === '1';
    else field.value = val;
  }
  form.addEventListener('change', () => {clearTimeout(debounce); refresh();});
  form.addEventListener('input', () => {clearTimeout(debounce); debounce = setTimeout(refresh, 200);});
  form.addEventListener('reset', () => setTimeout(refresh, 0));
  refresh();
})();
