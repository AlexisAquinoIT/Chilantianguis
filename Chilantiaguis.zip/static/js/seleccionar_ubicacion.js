(() => {
  const tipo = document.getElementById('tipo_registro');
  const indep = document.getElementById('campos-independiente');
  const tianguis = document.getElementById('campo-tianguis');
  const referencia = document.getElementById('campo-referencia');
  const form = document.getElementById('registro-negocio');
  let mapa = null, marker = null;
  function cambia() {
    const nuevo = tipo.value !== 'tianguis';
    indep.hidden = !nuevo; tianguis.hidden = nuevo; referencia.hidden = nuevo;
    document.getElementById('comercio_id').required = !nuevo;
    for (const id of ['alcaldia','colonia','direccion']) document.getElementById(id).required = nuevo;
    if (nuevo && window.L) {
      if (!mapa) {
        mapa = L.map('selector-ubicacion').setView([19.4326,-99.1332], 11);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom:19, attribution:'© OpenStreetMap contributors'}).addTo(mapa);
        mapa.on('click', (e) => {
          const {lat,lng} = e.latlng;
          document.getElementById('lat').value = lat.toFixed(6);
          document.getElementById('lng').value = lng.toFixed(6);
          if (marker) marker.setLatLng(e.latlng);
          else marker = L.marker(e.latlng).addTo(mapa);
          document.getElementById('ubicacion-elegida').textContent = 'Ubicación seleccionada ✓ (puedes cambiarla haciendo clic otra vez)';
        });
      }
      setTimeout(() => mapa.invalidateSize(), 80);
    }
  }
  tipo.addEventListener('change', cambia);
  form.addEventListener('submit',(e) => {
    if (tipo.value!=='tianguis' && (!document.getElementById('lat').value || !document.getElementById('lng').value)) {
      e.preventDefault();alert('Marca el negocio sobre el mapa antes de guardar.');
    }
  });
  cambia();
})();
