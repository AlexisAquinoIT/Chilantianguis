"""Chilantianguis CDMX — MVP de hackatón en Flask y SQLite.

Horarios y remates se expresan en hora local de Ciudad de México.
La base de datos nueva se crea al iniciar; la semilla opcional se carga con `flask demo`.
"""
import os
import re
import secrets
import sqlite3
from urllib.parse import quote
from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from functools import wraps
from pathlib import Path
from uuid import uuid4
from PIL import Image, UnidentifiedImageError
Image.MAX_IMAGE_PIXELS = 16_000_000  # límite para fotografías en esta demo
from zoneinfo import ZoneInfo

from dotenv import load_dotenv
from flask import (Flask, abort, flash, g, jsonify, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

load_dotenv()
BASE = Path(__file__).resolve().parent
TZ = ZoneInfo("America/Mexico_City")
TIPOS = {"tianguis": "Tianguis", "mercado": "Mercado público",
         "tienda": "Tienda de barrio", "negocio": "Pequeño negocio"}
DIAS = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
ALCALDIAS = ["Álvaro Obregón", "Azcapotzalco", "Benito Juárez", "Coyoacán",
             "Cuajimalpa de Morelos", "Cuauhtémoc", "Gustavo A. Madero", "Iztacalco",
             "Iztapalapa", "La Magdalena Contreras", "Miguel Hidalgo", "Milpa Alta",
             "Tláhuac", "Tlalpan", "Venustiano Carranza", "Xochimilco"]

# Únicamente los 16 tianguis ya precargados en cargar_64_comercios.py.
# La comparación exige también la alcaldía para evitar coincidencias equivocadas.
TIANGUIS_PREDEFINIDOS = {
    ("Tianguis de La Banderita", "Álvaro Obregón"),
    ("Tianguis de la Providencia", "Azcapotzalco"),
    ("Tianguis Nápoles", "Benito Juárez"),
    ("Tianguis de la Bola", "Coyoacán"),
    ("Tianguis Cuajimalpa Centro", "Cuajimalpa de Morelos"),
    ("Tianguis de la Lagunilla", "Cuauhtémoc"),
    ("Tianguis de la San Felipe de Jesús", "Gustavo A. Madero"),
    ("Tianguis Apatlaco", "Iztacalco"),
    ("Tianguis de Santa Cruz Meyehualco", "Iztapalapa"),
    ("Tianguis de San Bernabé", "La Magdalena Contreras"),
    ("Tianguis de Polanco", "Miguel Hidalgo"),
    ("Tianguis de Villa Milpa Alta", "Milpa Alta"),
    ("Tianguis de San Francisco Tlaltenco", "Tláhuac"),
    ("Tianguis de la Colonia Toriello Guerra", "Tlalpan"),
    ("Tianguis Balbuena", "Venustiano Carranza"),
    ("Tianguis de Nativitas", "Xochimilco"),
}

CODIGO_SMS_DEMO = "111111"  # SIMULACIÓN; nunca usar como OTP real en producción.
SMS_VIGENCIA_SEGUNDOS = 300
SMS_MAX_INTENTOS = 5
SMS_ESPERA_REENVIO = 30


def telefono_valido(valor):
    """Acepta diez dígitos mexicanos con o sin prefijo +52."""
    limpio = re.sub(r"[\s()\-]", "", valor or "")
    if limpio.startswith("+52"):
        limpio = limpio[3:]
    elif limpio.startswith("52") and len(limpio) == 12:
        limpio = limpio[2:]
    return limpio if re.fullmatch(r"[0-9]{10}", limpio) else None



def create_app(test_config=None):
    app = Flask(__name__, instance_path=str(BASE / "instance"), instance_relative_config=True)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY") or "SOLO-DESARROLLO-CAMBIA-ESTA-CLAVE",
        DATABASE=str(BASE / "instance" / "chilantiaguis.sqlite3"),
        MAX_CONTENT_LENGTH=5 * 1024 * 1024,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
    )
    if test_config:
        app.config.update(test_config)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    (BASE / "static" / "uploads").mkdir(parents=True, exist_ok=True)

    def db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["DATABASE"], timeout=10)
            g.db.row_factory = sqlite3.Row
            g.db.execute("PRAGMA foreign_keys = ON")
        return g.db

    @app.teardown_appcontext
    def close_db(_error=None):
        conn = g.pop("db", None)
        if conn is not None:
            conn.close()

    def migrar_usuarios():
        # Conserva los usuarios, puestos y productos de la versión con correo.
        columnas = {r[1] for r in db().execute("PRAGMA table_info(usuarios)")}
        for columna, definicion in (
            ("telefono", "TEXT"),
            ("apellidos", "TEXT NOT NULL DEFAULT ''"),
            ("alcaldia_usuario", "TEXT NOT NULL DEFAULT ''"),
            ("whatsapp_publico", "INTEGER NOT NULL DEFAULT 0"),
        ):
            if columna not in columnas:
                db().execute(f"ALTER TABLE usuarios ADD COLUMN {columna} {definicion}")
        db().execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_usuarios_telefono "
                     "ON usuarios(telefono) WHERE telefono IS NOT NULL")

    def migrar_tienda():
        """Ampliaciones compatibles con SQLite existentes; NO borrar instance/."""
        cols = {r[1] for r in db().execute("PRAGMA table_info(productos)")}
        if "unidad" not in cols:
            db().execute("ALTER TABLE productos ADD COLUMN unidad TEXT NOT NULL DEFAULT 'pieza'")
        if "stock" not in cols:
            # Registro antiguo: existencias no verificadas (0 hasta ajuste manual).
            db().execute("ALTER TABLE productos ADD COLUMN stock INTEGER NOT NULL DEFAULT 0")
        db().execute("""CREATE TABLE IF NOT EXISTS pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT NOT NULL UNIQUE,
            puesto_id INTEGER NOT NULL REFERENCES puestos(id),
            comprador TEXT NOT NULL,
            telefono TEXT NOT NULL,
            modalidad TEXT NOT NULL CHECK(modalidad IN ('presencial','en_linea')),
            estado TEXT NOT NULL DEFAULT 'nuevo'
               CHECK(estado IN ('nuevo','preparando','listo','entregado','cancelado')),
            total_centavos INTEGER NOT NULL CHECK(total_centavos>=0),
            creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        db().execute("""CREATE TABLE IF NOT EXISTS pedido_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pedido_id INTEGER NOT NULL REFERENCES pedidos(id),
            producto_id INTEGER NOT NULL REFERENCES productos(id),
            nombre TEXT NOT NULL,
            unidad TEXT NOT NULL,
            cantidad INTEGER NOT NULL CHECK(cantidad>0),
            precio_unitario_centavos INTEGER NOT NULL CHECK(precio_unitario_centavos>0)
        )""")
        db().execute("CREATE INDEX IF NOT EXISTS idx_pedidos_puesto ON pedidos(puesto_id)")

    def migrar_mayoreo():
        """Tablas nuevas: se crean sin borrar ni tocar los datos ya existentes."""
        db().executescript("""
        CREATE TABLE IF NOT EXISTS grupos_mayoreo (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            creador_id INTEGER NOT NULL REFERENCES usuarios(id),
            proveedor TEXT NOT NULL,
            producto TEXT NOT NULL,
            descripcion TEXT NOT NULL DEFAULT '',
            unidad TEXT NOT NULL,
            precio_unitario_centavos INTEGER NOT NULL CHECK(precio_unitario_centavos>0),
            cantidad_objetivo INTEGER NOT NULL CHECK(cantidad_objetivo>0),
            fecha_limite TEXT NOT NULL,
            estado TEXT NOT NULL DEFAULT 'abierto'
                CHECK(estado IN ('abierto','completo','cancelado')),
            creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS aportaciones_mayoreo (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            grupo_id INTEGER NOT NULL REFERENCES grupos_mayoreo(id),
            comerciante_id INTEGER NOT NULL REFERENCES usuarios(id),
            cantidad INTEGER NOT NULL DEFAULT 0 CHECK(cantidad>=0),
            monto_centavos INTEGER NOT NULL DEFAULT 0 CHECK(monto_centavos>=0),
            creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(grupo_id, comerciante_id)
        );
        CREATE INDEX IF NOT EXISTS idx_aportaciones_grupo ON aportaciones_mayoreo(grupo_id);
        """)

    def init_db():
        db().executescript((BASE / "schema.sql").read_text(encoding="utf-8"))
        migrar_usuarios()
        migrar_tienda()
        migrar_mayoreo()
        categories = ["Frutas y verduras", "Abarrotes", "Ropa y calzado", "Comida preparada",
                      "Artesanías", "Electrónica", "Hogar", "Flores y plantas", "Otros"]
        db().executemany("INSERT OR IGNORE INTO categorias(nombre) VALUES (?)", [(x,) for x in categories])
        db().commit()

    @app.cli.command("init-db")
    def init_db_cli():
        init_db()
        print("Base de datos inicializada.")

    @app.cli.command("demo")
    def demo_cli():
        from seed import create_demo
        init_db()
        print(create_demo(db()))

    with app.app_context():
        init_db()

    def now_local():
        return datetime.now(TZ).strftime("%Y-%m-%dT%H:%M")

    def current_user():
        uid = session.get("user_id")
        return db().execute("SELECT id,nombre,apellidos,telefono,rol,whatsapp_publico FROM usuarios WHERE id=?", (uid,)).fetchone() if uid else None

    @app.before_request
    def load_user_and_check_csrf():
        g.user = current_user()
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            token = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token")
            if not token or not secrets.compare_digest(token, session.get("csrf_token", "")):
                abort(400, "Token de seguridad inválido; actualiza la página e intenta de nuevo.")

    def csrf_token():
        if "csrf_token" not in session:
            session["csrf_token"] = secrets.token_urlsafe(32)
        return session["csrf_token"]

    def dinero(value):
        return f"${value / 100:,.2f}"

    def producto_lista(id_puesto):
        return db().execute("SELECT * FROM productos WHERE puesto_id=? ORDER BY id DESC", (id_puesto,)).fetchall()

    UNIDADES = ["pieza", "kg", "bolsa", "paquete", "litro", "docena", "porción", "servicio"]
    # Precios ilustrativos para la demo, NO cotizaciones reales.
    PLANTILLAS = {
      "Frutas y verduras": [("Jitomate", 28, "kg"), ("Plátano", 32, "kg"), ("Naranja", 26, "kg")],
      "Abarrotes": [("Arroz", 36, "kg"), ("Frijol", 42, "kg"), ("Azúcar", 28, "bolsa")],
      "Ropa y calzado": [("Playera", 95, "pieza"), ("Calcetines", 55, "paquete")],
      "Comida preparada": [("Quesadilla", 35, "pieza"), ("Taco de guisado", 25, "pieza")],
      "Artesanías": [("Pulsera artesanal", 50, "pieza"), ("Bolsa tejida", 185, "pieza")],
      "Electrónica": [("Cable USB", 75, "pieza"), ("Audífonos", 180, "pieza")],
      "Hogar": [("Jabón", 24, "pieza"), ("Escoba", 65, "pieza")],
      "Flores y plantas": [("Ramo de rosas", 120, "paquete"), ("Suculenta", 50, "pieza")],
      "Otros": [("Servicio básico", 150, "servicio"), ("Artículo variado", 45, "pieza")],
    }

    def foto_local(file):
        """Guarda fotografía en ubicación estática tras verificar y recomprimir con Pillow."""
        if not file or not file.filename:
            return None
        try:
            file.stream.seek(0)
            with Image.open(file.stream) as im:
                im.verify()
            file.stream.seek(0)
            with Image.open(file.stream) as im:
                if im.format not in {"JPEG", "PNG", "WEBP"}:
                    raise ValueError("La foto debe ser JPG, PNG o WebP.")
                im.thumbnail((1200, 1200))
                img = im.convert("RGB")
                ruta = f"uploads/{uuid4().hex}.jpg"
                img.save(BASE / "static" / ruta, "JPEG", quality=82, optimize=True)
                return ruta
        except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError):
            raise ValueError("No se pudo procesar la fotografía. Elige JPG, PNG o WebP.") from None

    def imagen_producto(url):
        return url_for("static", filename=url) if (url or "").startswith("uploads/") else url

    def precio_actual(producto, instante):
        remate = db().execute("""SELECT descuento FROM remates
          WHERE producto_id=? AND inicio<=? AND fin>?
          ORDER BY descuento DESC LIMIT 1""", (producto["id"], instante, instante)).fetchone()
        if not remate:
            return producto["precio_centavos"]
        return max(1, (producto["precio_centavos"] * (100 - remate["descuento"]) + 50) // 100)

    def enlace_whatsapp(telefono, autorizado, mensaje):
        """Nunca exponer teléfonos sin permiso explícito del comerciante."""
        numero = telefono_valido(telefono) if autorizado else None
        if not numero:
            return None
        return "https://wa.me/52" + numero + "?text=" + quote(mensaje, safe="")

    def carrito_actual():
        c = session.get("carrito") or {}
        return c if isinstance(c, dict) else {}

    def carrito_resumen():
        c = carrito_actual()
        if not c.get("puesto_id") or not isinstance(c.get("items"), dict):
            return None, [], 0
        puesto = db().execute("""SELECT pt.*, co.nombre comercio, co.direccion, co.colonia,
          co.alcaldia, co.tipo, u.nombre vendedor, u.apellidos vendedor_apellidos,
          u.telefono whatsapp_telefono, u.whatsapp_publico
          FROM puestos pt JOIN comercios co ON co.id=pt.comercio_id
          JOIN usuarios u ON u.id=pt.vendedor_id WHERE pt.id=?""", (c["puesto_id"],)).fetchone()
        if not puesto:
            return None, [], 0
        items, total = [], 0
        for ident, cantidad in list(c["items"].items())[:30]:
            try:
                cant = int(cantidad)
                prodid = int(ident)
            except (ValueError, TypeError):
                continue
            if not 1 <= cant <= 20:
                continue
            prod = db().execute("SELECT * FROM productos WHERE id=? AND puesto_id=? AND disponible=1",
                                (prodid, puesto["id"])).fetchone()
            if not prod:
                continue
            precio = precio_actual(prod, now_local())
            subtotal = precio * cant
            items.append(dict(producto=prod, cantidad=cant, precio=precio, subtotal=subtotal))
            total += subtotal
        return puesto, items, total

    @app.context_processor
    def inject_globals():
        return dict(usuario=g.get("user"), csrf_token=csrf_token, tipos=TIPOS, dias=DIAS,
                    producto_lista=producto_lista, imagen_producto=imagen_producto,
                    alcaldias=ALCALDIAS, dinero=dinero, now_local=now_local())

    def requiere_login(rol=None):
        def decorator(fn):
            @wraps(fn)
            def wrapped(*args, **kwargs):
                if not g.user:
                    flash("Inicia sesión para continuar.", "warning")
                    return redirect(url_for("login"))
                if rol and g.user["rol"] != rol:
                    abort(403)
                return fn(*args, **kwargs)
            return wrapped
        return decorator

    def error_form(message, endpoint, **params):
        flash(message, "error")
        return redirect(url_for(endpoint, **params))

    def url_imagen(value):
        url = (value or "").strip()
        if url and not re.match(r"^https://[^\s<>\"']+$", url, re.I):
            raise ValueError("La imagen debe ser una URL HTTPS válida (o dejarse vacía).")
        return url[:1000]

    def validar_puesto(id_puesto):
        puesto = db().execute("SELECT * FROM puestos WHERE id=?", (id_puesto,)).fetchone()
        if not puesto:
            abort(404)
        if puesto["vendedor_id"] != g.user["id"]:
            abort(403)
        return puesto

    def validar_producto(id_producto):
        product = db().execute("SELECT p.* FROM productos p JOIN puestos pt ON pt.id=p.puesto_id "
                               "WHERE p.id=? AND pt.vendedor_id=?", (id_producto, g.user["id"])).fetchone()
        if not product:
            abort(403)
        return product

    def guardar_horarios(id_comercio):
        dias_seleccionados = request.form.getlist("dias")
        try:
            dias_nums = sorted(set(int(d) for d in dias_seleccionados))
        except ValueError:
            raise ValueError("Días de operación inválidos.") from None
        if not dias_nums or any(d not in range(7) for d in dias_nums):
            raise ValueError("Selecciona al menos un día de operación.")
        inicio = request.form.get("hora_inicio", "").strip()
        fin = request.form.get("hora_fin", "").strip()
        if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", inicio) or not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", fin) or inicio >= fin:
            raise ValueError("El horario debe tener horas válidas y terminar después de iniciar.")
        db().execute("DELETE FROM horarios WHERE comercio_id=?", (id_comercio,))
        db().executemany("INSERT INTO horarios(comercio_id,dia,inicio,fin) VALUES(?,?,?,?)",
                         [(id_comercio, d, inicio, fin) for d in dias_nums])

    @app.route("/")
    def index():
        counts = db().execute("SELECT tipo, COUNT(*) total FROM comercios GROUP BY tipo").fetchall()
        return render_template("home.html", counts={r["tipo"]: r["total"] for r in counts})

    def tianguis_disponibles():
        # No permite añadir puestos a un comercio no incluido en los 16 de prueba.
        rows = db().execute(
            "SELECT id,nombre,alcaldia,tipo FROM comercios WHERE tipo='tianguis' "
            "ORDER BY alcaldia, nombre COLLATE NOCASE"
        ).fetchall()
        return [r for r in rows if (r["nombre"], r["alcaldia"]) in TIANGUIS_PREDEFINIDOS]

    def solicitar_codigo(modo):
        telefono = telefono_valido(request.form.get("telefono", ""))
        if not telefono:
            return error_form("Escribe un celular mexicano de 10 dígitos.", modo)
        existe = db().execute("SELECT id FROM usuarios WHERE telefono=?", (telefono,)).fetchone()
        if modo == "registro" and existe:
            return error_form("Ese número ya tiene cuenta. Entra como comerciante.", "login")
        if modo == "login" and not existe:
            return error_form("Ese número aún no está registrado. Crea tu cuenta.", "registro")

        ahora = int(datetime.now(TZ).timestamp())
        anterior = session.get("sms_pendiente", {})
        if anterior.get("telefono") == telefono and ahora - anterior.get("creado", 0) < SMS_ESPERA_REENVIO:
            flash("Código simulado ya solicitado. Usa 111111; espera 30 segundos antes de reenviar.", "warning")
            return redirect(url_for("verificar_codigo"))
        # En producción, aquí se generaría un código aleatorio y se enviaría por SMS.
        session.pop("sms_verificado", None)
        session["sms_pendiente"] = {
            "telefono": telefono, "modo": modo, "creado": ahora, "intentos": 0
        }
        session.modified = True
        flash("SMS de demostración: tu código es 111111 (no se envió un mensaje real).", "success")
        return redirect(url_for("verificar_codigo"))

    @app.route("/registro", methods=["GET", "POST"])
    def registro():
        if g.user:
            return redirect(url_for("panel"))
        if request.method == "POST":
            return solicitar_codigo("registro")
        return render_template("auth.html", mode="registro")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if g.user:
            return redirect(url_for("panel"))
        if request.method == "POST":
            return solicitar_codigo("login")
        return render_template("auth.html", mode="login")

    @app.route("/verificar-codigo", methods=["GET", "POST"])
    def verificar_codigo():
        pendiente = session.get("sms_pendiente")
        if not pendiente:
            return redirect(url_for("registro"))
        ahora = int(datetime.now(TZ).timestamp())
        if ahora - pendiente["creado"] > SMS_VIGENCIA_SEGUNDOS:
            session.pop("sms_pendiente", None)
            return error_form("El código expiró. Solicita uno nuevo.", pendiente["modo"])
        if request.method == "POST":
            codigo = request.form.get("codigo", "").strip()
            if pendiente.get("intentos", 0) >= SMS_MAX_INTENTOS:
                session.pop("sms_pendiente", None)
                return error_form("Demasiados intentos. Solicita un código nuevo.", pendiente["modo"])
            pendiente["intentos"] += 1
            session["sms_pendiente"] = pendiente
            if not secrets.compare_digest(codigo, CODIGO_SMS_DEMO):
                if pendiente["intentos"] >= SMS_MAX_INTENTOS:
                    session.pop("sms_pendiente", None)
                    return error_form("Demasiados intentos. Solicita un código nuevo.", pendiente["modo"])
                flash("Código incorrecto. En esta demostración usa 111111.", "error")
            else:
                telefono = pendiente["telefono"]
                modo = pendiente["modo"]
                session.pop("sms_pendiente", None)
                if modo == "login":
                    usuario = db().execute("SELECT id FROM usuarios WHERE telefono=?", (telefono,)).fetchone()
                    if not usuario:
                        return error_form("No encontramos la cuenta. Regístrate.", "registro")
                    session.clear()
                    session["user_id"] = usuario["id"]
                    flash("¡Bienvenido de nuevo!", "success")
                    return redirect(url_for("panel"))
                session["sms_verificado"] = {"telefono": telefono, "creado": ahora}
                return redirect(url_for("datos_comerciante"))
        return render_template("verificar_sms.html", telefono=pendiente["telefono"],
                               modo=pendiente["modo"], intentos_restantes=SMS_MAX_INTENTOS - pendiente.get("intentos", 0))

    @app.route("/datos-comerciante", methods=["GET", "POST"])
    def datos_comerciante():
        verificado = session.get("sms_verificado")
        ahora = int(datetime.now(TZ).timestamp())
        if not verificado or ahora - verificado["creado"] > 15 * 60:
            session.pop("sms_verificado", None)
            flash("Verifica primero tu número de celular.", "warning")
            return redirect(url_for("registro"))
        telefono = verificado["telefono"]
        if request.method == "POST":
            nombre = request.form.get("nombre", "").strip()
            apellidos = request.form.get("apellidos", "").strip()
            alcaldia_usuario = request.form.get("alcaldia_usuario", "").strip()
            acepta = request.form.get("privacidad") == "si"
            if not 2 <= len(nombre) <= 80 or not 2 <= len(apellidos) <= 100 or alcaldia_usuario not in ALCALDIAS or not acepta:
                flash("Completa nombre, apellidos, alcaldía y acepta el aviso de privacidad.", "error")
                return render_template("datos_comerciante.html", telefono=telefono), 400
            # Campos antiguos email/password_hash siguen siendo NOT NULL en SQLite;
            # se rellenan internamente con valores inservibles para acceso.
            correo_interno = f"sms-{telefono}@usuarios.chilantiaguis.invalid"
            try:
                with db():
                    cur = db().execute(
                        "INSERT INTO usuarios(nombre,apellidos,alcaldia_usuario,telefono,email,password_hash,rol) "
                        "VALUES(?,?,?,?,?,?,'comerciante')",
                        (nombre, apellidos, alcaldia_usuario, telefono, correo_interno,
                         generate_password_hash(secrets.token_urlsafe(32)))
                    )
            except sqlite3.IntegrityError:
                session.pop("sms_verificado", None)
                return error_form("Ese número ya está registrado. Inicia sesión.", "login")
            session.clear()
            session["user_id"] = cur.lastrowid
            flash("¡Registro terminado! Ya puedes agregar varios puestos.", "success")
            return redirect(url_for("panel"))
        return render_template("datos_comerciante.html", telefono=telefono)

    @app.post("/salir")
    def salir():
        session.clear()
        return redirect(url_for("index"))

    @app.route("/explorar")
    def explorar():
        categorias = db().execute("SELECT * FROM categorias ORDER BY nombre").fetchall()
        return render_template("explorar.html", categorias=categorias)

    @app.get("/api/comercios")
    def api_comercios():
        filtros = []
        params = []
        q = request.args.get("q", "").strip()[:100]
        tipo = request.args.get("tipo", "")
        alcaldia = request.args.get("alcaldia", "")
        categoria = request.args.get("categoria", "")
        dia = request.args.get("dia", "")
        remates = request.args.get("remates", "")
        if q:
            filtros.append("(c.nombre LIKE ? OR c.descripcion LIKE ? OR c.colonia LIKE ? OR c.direccion LIKE ? OR c.alcaldia LIKE ? OR EXISTS (SELECT 1 FROM puestos pt JOIN productos p ON p.puesto_id=pt.id WHERE pt.comercio_id=c.id AND (p.nombre LIKE ? OR pt.nombre LIKE ?)))")
            params.extend([f"%{q}%"] * 7)
        if tipo in TIPOS:
            filtros.append("c.tipo=?")
            params.append(tipo)
        if alcaldia in ALCALDIAS:
            filtros.append("c.alcaldia=?")
            params.append(alcaldia)
        if categoria.isdecimal():
            filtros.append("EXISTS (SELECT 1 FROM puestos pt JOIN productos p ON p.puesto_id=pt.id WHERE pt.comercio_id=c.id AND p.categoria_id=?)")
            params.append(int(categoria))
        if dia.isdecimal() and 0 <= int(dia) <= 6:
            filtros.append("EXISTS (SELECT 1 FROM horarios h WHERE h.comercio_id=c.id AND h.dia=?)")
            params.append(int(dia))
        now = now_local()
        # El filtro de remates activos refleja el horario local de CDMX.
        activo_sql = """EXISTS (SELECT 1 FROM puestos pt JOIN productos p ON p.puesto_id=pt.id
            JOIN remates r ON r.producto_id=p.id WHERE pt.comercio_id=c.id
            AND p.disponible=1 AND p.stock>0 AND r.inicio<=? AND r.fin>?)"""
        if remates == "1":
            filtros.append(activo_sql)
            params.extend([now, now])
        where = " WHERE " + " AND ".join(filtros) if filtros else ""
        rows = db().execute(f"""SELECT c.*,
           (SELECT COUNT(*) FROM puestos WHERE comercio_id=c.id) puestos_total,
           (SELECT GROUP_CONCAT(x.dia || '|' || x.inicio || '|' || x.fin, ';')
             FROM (SELECT h.dia, h.inicio, h.fin FROM horarios h
                   WHERE h.comercio_id=c.id ORDER BY h.dia) x) AS horarios_text,
           (SELECT GROUP_CONCAT(pt.nombre, ', ') FROM puestos pt
             WHERE pt.comercio_id=c.id) AS puestos_nombres,
           (SELECT COUNT(*) FROM productos p JOIN puestos pt ON pt.id=p.puesto_id WHERE pt.comercio_id=c.id AND p.disponible=1 AND p.stock>0) productos_total,
           {activo_sql} AS remate_activo
           FROM comercios c {where} ORDER BY c.nombre COLLATE NOCASE""",
           [now, now, *params]).fetchall()
        return jsonify([dict(r) for r in rows])

    @app.get("/comercio/<int:id_comercio>")
    def comercio_detalle(id_comercio):
        comercio = db().execute("SELECT * FROM comercios WHERE id=?", (id_comercio,)).fetchone()
        if not comercio:
            abort(404)
        horarios = db().execute("SELECT * FROM horarios WHERE comercio_id=? ORDER BY dia", (id_comercio,)).fetchall()
        puestos = db().execute("""SELECT pt.*, u.nombre vendedor,
            (SELECT COUNT(*) FROM productos WHERE puesto_id=pt.id) total_productos
            FROM puestos pt JOIN usuarios u ON u.id=pt.vendedor_id WHERE pt.comercio_id=? ORDER BY pt.nombre""",
                              (id_comercio,)).fetchall()
        return render_template("comercio.html", comercio=comercio, horarios=horarios, puestos=puestos)

    @app.get("/puesto/<int:id_puesto>")
    def puesto_detalle(id_puesto):
        puesto = db().execute("""SELECT pt.*, c.nombre comercio, c.id comercio_id,
            c.alcaldia, u.nombre vendedor, u.telefono whatsapp_telefono,
            u.whatsapp_publico FROM puestos pt JOIN comercios c ON c.id=pt.comercio_id
            JOIN usuarios u ON u.id=pt.vendedor_id WHERE pt.id=?""", (id_puesto,)).fetchone()
        if not puesto:
            abort(404)
        now = now_local()
        productos = db().execute("""SELECT p.*, cat.nombre categoria, r.id remate_id,
            r.descuento, r.inicio remate_inicio, r.fin remate_fin FROM productos p
            JOIN categorias cat ON cat.id=p.categoria_id
            LEFT JOIN remates r ON r.id=(SELECT rr.id FROM remates rr
              WHERE rr.producto_id=p.id AND rr.fin>? ORDER BY
              CASE WHEN rr.inicio<=? THEN 0 ELSE 1 END, rr.inicio ASC LIMIT 1)
            WHERE p.puesto_id=? ORDER BY p.nombre""", (now, now, id_puesto)).fetchall()
        wa_url = enlace_whatsapp(
            puesto["whatsapp_telefono"], puesto["whatsapp_publico"],
            f"Hola, vi tu puesto {puesto['nombre']} en Chilantianguis y quisiera consultar tus productos."
        )
        return render_template("puesto.html", puesto=puesto, productos=productos, whatsapp_url=wa_url)

    @app.post("/panel/whatsapp")
    @requiere_login("comerciante")
    def configurar_whatsapp():
        permitir = 1 if request.form.get("whatsapp_publico") == "1" else 0
        if permitir and not telefono_valido(g.user["telefono"]):
            flash("Tu cuenta necesita un celular de 10 dígitos para activar WhatsApp.", "warning")
            return redirect(url_for("panel"))
        db().execute("UPDATE usuarios SET whatsapp_publico=? WHERE id=?", (permitir, g.user["id"]))
        db().commit()
        flash("Preferencia de WhatsApp actualizada.", "success")
        return redirect(url_for("panel"))

    @app.get("/panel")
    @requiere_login("comerciante")
    def panel():
        puestos = db().execute("""SELECT pt.*, c.nombre comercio, c.tipo,
            (SELECT COUNT(*) FROM productos WHERE puesto_id=pt.id) total_productos
            FROM puestos pt JOIN comercios c ON c.id=pt.comercio_id
            WHERE vendedor_id=? ORDER BY pt.id DESC""", (g.user["id"],)).fetchall()
        pedidos = db().execute("""SELECT ped.*, pt.nombre puesto FROM pedidos ped
          JOIN puestos pt ON pt.id=ped.puesto_id WHERE pt.vendedor_id=?
          ORDER BY ped.id DESC LIMIT 40""", (g.user["id"],)).fetchall()
        return render_template("panel.html", puestos=puestos, pedidos=pedidos)

    # Alta de tianguis: exclusiva del flujo de solicitud y revisión administrativa.
    # No permitir que un comerciante cree/edite la ubicación mediante URL directa.
    @app.route("/comercio/nuevo", methods=["GET", "POST"])
    @app.route("/comercio/<int:id_comercio>/editar", methods=["GET", "POST"])
    @requiere_login("comerciante")
    def comercio_bloqueado(id_comercio=None):
        abort(403, "Los comerciantes solo pueden registrar puestos en tianguis precargados.")

    @app.route("/puesto/nuevo", methods=["GET", "POST"])
    @requiere_login("comerciante")
    def puesto_nuevo():
        comercios = tianguis_disponibles()
        if request.method == "POST":
            tipo_registro = request.form.get("tipo_registro", "tianguis")
            nombre = request.form.get("nombre", "").strip()
            if not 3 <= len(nombre) <= 120:
                return error_form("Pon un nombre de al menos tres caracteres.", "puesto_nuevo")
            try:
                if tipo_registro == "tianguis":
                    comercio_id = int(request.form.get("comercio_id", ""))
                    if comercio_id not in {c["id"] for c in comercios}:
                        raise ValueError("Elige un tianguis precargado.")
                elif tipo_registro in ("tienda", "negocio"):
                    # Ubicación seleccionada en el mapa, no tecleada por el usuario.
                    alcaldia = request.form.get("alcaldia", "")
                    colonia = request.form.get("colonia", "").strip()
                    direccion = request.form.get("direccion", "").strip()
                    lat = float(request.form.get("lat", ""))
                    lng = float(request.form.get("lng", ""))
                    if alcaldia not in ALCALDIAS or not (3 <= len(colonia) <= 100) or not (5 <= len(direccion) <= 200):
                        raise ValueError("Indica alcaldía, colonia y dirección.")
                    if not 19.0 <= lat <= 20.0 or not -100.0 <= lng <= -98.0:
                        raise ValueError("Marca la ubicación de tu negocio dentro de la zona de CDMX en el mapa.")
                else:
                    raise ValueError("Selecciona puesto de tianguis, tienda o negocio.")
                # No usar una URL aportada por usuario: opción de imagen de puesto sigue siendo opcional.
                with db():
                    if tipo_registro != "tianguis":
                        cur_comercio = db().execute("""INSERT INTO comercios
                          (propietario_id,nombre,tipo,descripcion,alcaldia,colonia,direccion,lat,lng,origen,verificado)
                          VALUES(?,?,?,?,?,?,?,?,?,'comerciante',0)""",
                          (g.user["id"], nombre, tipo_registro,
                           "Comercio registrado por su vendedor. Ubicación autodeclarada, sin verificar.",
                           alcaldia, colonia, direccion, lat, lng))
                        comercio_id = cur_comercio.lastrowid
                        guardar_horarios(comercio_id)
                    cur = db().execute("""INSERT INTO puestos
                      (comercio_id,vendedor_id,nombre,descripcion,referencia,imagen_url)
                      VALUES(?,?,?,?,?,?)""", (comercio_id, g.user["id"], nombre,
                      request.form.get("descripcion", "")[:1000],
                      request.form.get("referencia", "")[:200], ""))
                flash("Puesto registrado. Ya aparece en el mapa; agrega productos.", "success")
                return redirect(url_for("producto_nuevo", id_puesto=cur.lastrowid))
            except (ValueError, OverflowError) as e:
                return error_form(str(e), "puesto_nuevo")
        return render_template("puesto_form.html", comercios=comercios, seleccionado=request.args.get("comercio_id", ""))

    @app.route("/producto/nuevo/<int:id_puesto>", methods=["GET", "POST"])
    @requiere_login("comerciante")
    def producto_nuevo(id_puesto):
        puesto = validar_puesto(id_puesto)
        return producto_form(0, puesto)

    @app.route("/producto/<int:id_producto>/editar", methods=["GET", "POST"])
    @requiere_login("comerciante")
    def producto_editar(id_producto):
        product = validar_producto(id_producto)
        return producto_form(id_producto, None)

    def producto_form(id_producto, puesto):
        producto = db().execute("SELECT * FROM productos WHERE id=?", (id_producto,)).fetchone() if id_producto else None
        id_puesto = producto["puesto_id"] if producto else puesto["id"]
        categorias = db().execute("SELECT * FROM categorias ORDER BY nombre").fetchall()
        if request.method == "POST":
            nombre = request.form.get("nombre", "").strip()
            try:
                precio = Decimal(request.form.get("precio", ""))
                cents = int((precio * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                categoria_id = int(request.form.get("categoria_id", ""))
                unidad = request.form.get("unidad", "")
                stock = int(request.form.get("stock", ""))
                if not 1 <= cents <= 100000000 or not 2 <= len(nombre) <= 120 or not db().execute(
                        "SELECT 1 FROM categorias WHERE id=?", (categoria_id,)).fetchone():
                    raise ValueError("Nombre, categoría o precio inválidos.")
                if unidad not in UNIDADES or not 0 <= stock <= 1000000:
                    raise ValueError("Selecciona unidad y un inventario válido (0 a 1,000,000).")
                imagen_url = foto_local(request.files.get("imagen")) or (producto["imagen_url"] if producto else "")
            except (ValueError, InvalidOperation, OverflowError):
                return error_form("Revisa nombre, categoría, precio, unidad, existencias o fotografía.",
                                  "producto_editar" if id_producto else "producto_nuevo",
                                  **({"id_producto": id_producto} if id_producto else {"id_puesto": id_puesto}))
            disponible = 1 if request.form.get("disponible") == "1" else 0
            with db():
                if id_producto:
                    db().execute("""UPDATE productos SET nombre=?,categoria_id=?,descripcion=?,precio_centavos=?,
                        imagen_url=?,disponible=?,unidad=?,stock=? WHERE id=?""",
                        (nombre, categoria_id, request.form.get("descripcion", "")[:1000], cents,
                         imagen_url, disponible, unidad, stock, id_producto))
                    producto_id = id_producto
                else:
                    cur = db().execute("""INSERT INTO productos
                      (puesto_id,nombre,categoria_id,descripcion,precio_centavos,imagen_url,disponible,unidad,stock)
                      VALUES(?,?,?,?,?,?,?,?,?)""", (id_puesto, nombre, categoria_id,
                      request.form.get("descripcion", "")[:1000], cents, imagen_url, disponible, unidad, stock))
                    producto_id = cur.lastrowid
            flash("Producto e inventario guardados. Puedes programar un remate para este producto.", "success")
            return redirect(url_for("remate_nuevo", id_producto=producto_id)
                            if request.form.get("crear_remate") == "1" else url_for("panel"))
        return render_template("producto_form.html", producto=producto, id_puesto=id_puesto,
                               categorias=categorias, unidades=UNIDADES, plantillas=PLANTILLAS)

    @app.route("/remate/nuevo/<int:id_producto>", methods=["GET", "POST"])
    @requiere_login("comerciante")
    def remate_nuevo(id_producto):
        producto = validar_producto(id_producto)
        if request.method == "POST":
            try:
                descuento = int(request.form.get("descuento", ""))
                inicio = datetime.strptime(request.form.get("inicio", ""), "%Y-%m-%dT%H:%M")
                fin = datetime.strptime(request.form.get("fin", ""), "%Y-%m-%dT%H:%M")
                if not 1 <= descuento <= 90 or fin <= inicio:
                    raise ValueError("El descuento debe estar entre 1 y 90%, y el fin ser posterior al inicio.")
                if fin <= datetime.now(TZ).replace(tzinfo=None):
                    raise ValueError("No puedes programar un remate que ya terminó.")
                overlapping = db().execute("""SELECT 1 FROM remates WHERE producto_id=? AND inicio<? AND fin>? LIMIT 1""",
                                           (id_producto, fin.strftime("%Y-%m-%dT%H:%M"), inicio.strftime("%Y-%m-%dT%H:%M"))).fetchone()
                if overlapping:
                    raise ValueError("Ya existe otro remate de ese producto en el mismo horario.")
            except (ValueError, OverflowError) as e:
                return error_form(str(e), "remate_nuevo", id_producto=id_producto)
            db().execute("INSERT INTO remates(producto_id,descuento,inicio,fin) VALUES(?,?,?,?)",
                         (id_producto, descuento, inicio.strftime("%Y-%m-%dT%H:%M"), fin.strftime("%Y-%m-%dT%H:%M")))
            db().commit()
            flash("¡Remate programado!", "success")
            return redirect(url_for("panel"))
        remates = db().execute("SELECT * FROM remates WHERE producto_id=? ORDER BY inicio DESC", (id_producto,)).fetchall()
        return render_template("remate_form.html", producto=producto, remates=remates)

    @app.post("/remate/<int:id_remate>/eliminar")
    @requiere_login("comerciante")
    def remate_eliminar(id_remate):
        r = db().execute("""SELECT r.*, p.puesto_id FROM remates r JOIN productos p ON p.id=r.producto_id
            JOIN puestos pt ON pt.id=p.puesto_id WHERE r.id=? AND pt.vendedor_id=?""",
                         (id_remate, g.user["id"])).fetchone()
        if not r:
            abort(403)
        db().execute("DELETE FROM remates WHERE id=?", (id_remate,))
        db().commit()
        flash("Remate eliminado.", "success")
        return redirect(url_for("remate_nuevo", id_producto=r["producto_id"]))


    @app.post("/carrito/agregar/<int:id_producto>")
    def carrito_agregar(id_producto):
        producto = db().execute("""SELECT p.*,pt.id como_puesto FROM productos p
          JOIN puestos pt ON pt.id=p.puesto_id WHERE p.id=?""", (id_producto,)).fetchone()
        if not producto or not producto["disponible"] or producto["stock"] < 1:
            flash("Producto agotado o inexistente.", "warning")
            return redirect(url_for("explorar"))
        try:
            cantidad = int(request.form.get("cantidad", "1"))
            if not 1 <= cantidad <= 20:
                raise ValueError
        except ValueError:
            abort(400, "Cantidad inválida")
        carrito = carrito_actual()
        if carrito.get("puesto_id") != producto["puesto_id"]:
            if carrito.get("items") and request.form.get("cambiar_puesto") != "si":
                flash("Tu carrito es de otro puesto. Vacíalo antes de comprar en uno diferente.", "warning")
                return redirect(url_for("carrito_ver"))
            carrito = {"puesto_id": producto["puesto_id"], "items": {}}
        items = carrito["items"]
        total = int(items.get(str(id_producto), 0)) + cantidad
        if total > producto["stock"]:
            flash(f"Solo quedan {producto['stock']} unidades disponibles.", "warning")
            return redirect(url_for("puesto_detalle", id_puesto=producto["puesto_id"]))
        items[str(id_producto)] = total
        session["carrito"] = carrito
        flash("Producto agregado al carrito.", "success")
        return redirect(url_for("puesto_detalle", id_puesto=producto["puesto_id"]))

    @app.route("/carrito", methods=["GET"])
    def carrito_ver():
        puesto, items, total = carrito_resumen()
        return render_template("carrito.html", puesto=puesto, items=items, total=total)

    @app.post("/carrito/actualizar")
    def carrito_actualizar():
        c = carrito_actual()
        items = c.get("items", {})
        try:
            id_producto = str(int(request.form.get("producto_id", "")))
            cantidad = int(request.form.get("cantidad", ""))
        except ValueError:
            abort(400)
        if id_producto not in items or not 0 <= cantidad <= 20:
            abort(400)
        if cantidad == 0:
            items.pop(id_producto, None)
        else:
            p = db().execute("SELECT stock FROM productos WHERE id=? AND puesto_id=?", (id_producto, c["puesto_id"])).fetchone()
            if not p or cantidad > p["stock"]:
                flash("No hay suficientes existencias para esa cantidad.", "warning")
                return redirect(url_for("carrito_ver"))
            items[id_producto] = cantidad
        if not items:
            session.pop("carrito", None)
        else:
            session["carrito"] = c
        return redirect(url_for("carrito_ver"))

    @app.post("/carrito/vaciar")
    def carrito_vaciar():
        session.pop("carrito", None)
        return redirect(url_for("explorar"))

    @app.route("/checkout", methods=["GET", "POST"])
    def checkout():
        puesto, items, total = carrito_resumen()
        if not puesto or not items:
            flash("Elige productos antes de confirmar tu pedido.", "warning")
            return redirect(url_for("carrito_ver"))
        if request.method == "POST":
            comprador = request.form.get("comprador", "").strip()
            # No solicitamos ni almacenamos el teléfono del comprador.
            # Se usa una cadena vacía porque la columna heredada es NOT NULL.
            telefono = ""
            modalidad = request.form.get("modalidad")
            if not 2 <= len(comprador) <= 100 or modalidad not in ("presencial", "en_linea"):
                flash("Escribe tu nombre y selecciona una modalidad.", "error")
                return render_template("checkout.html", puesto=puesto, items=items, total=total), 400
            if request.form.get("acepto_demo") != "si":
                flash("Confirma que entiendes que no se procesará ningún pago real.", "warning")
                return render_template("checkout.html", puesto=puesto, items=items, total=total), 400
            codigo = uuid4().hex[:12].upper()
            con = db()
            try:
                # Escritura serializada: impedir que dos compras resten el mismo inventario.
                con.execute("BEGIN IMMEDIATE")
                importe = 0
                linea_pedido = []
                for item in items:
                    prodid = item["producto"]["id"]
                    actual = con.execute("SELECT * FROM productos WHERE id=? AND puesto_id=? AND disponible=1",
                                         (prodid, puesto["id"])).fetchone()
                    if not actual or actual["stock"] < item["cantidad"]:
                        raise ValueError(f"Ya no quedan suficientes existencias de {item['producto']['nombre']}.")
                    unitario = precio_actual(actual, now_local())
                    linea_pedido.append((actual, item["cantidad"], unitario))
                    importe += item["cantidad"] * unitario
                for prod, cant, _ in linea_pedido:
                    actualizado = con.execute(
                        "UPDATE productos SET stock=stock-? WHERE id=? AND stock>=?",
                        (cant, prod["id"], cant)
                    )
                    if actualizado.rowcount != 1:
                        raise ValueError("Se agotó un producto mientras confirmabas. Revisa el carrito.")
                cur = con.execute("""INSERT INTO pedidos
                  (codigo,puesto_id,comprador,telefono,modalidad,total_centavos)
                  VALUES(?,?,?,?,?,?)""", (codigo, puesto["id"], comprador, telefono, modalidad, importe))
                for prod, cant, precio in linea_pedido:
                    con.execute("""INSERT INTO pedido_items
                      (pedido_id,producto_id,nombre,unidad,cantidad,precio_unitario_centavos)
                      VALUES(?,?,?,?,?,?)""", (cur.lastrowid, prod["id"], prod["nombre"], prod["unidad"], cant, precio))
                con.commit()
            except (ValueError, sqlite3.Error) as e:
                con.rollback()
                flash(str(e), "error")
                return redirect(url_for("carrito_ver"))
            session.pop("carrito", None)
            codigos = list(session.get("mis_pedidos", []))[-9:]
            codigos.append(codigo)
            session["mis_pedidos"] = codigos
            return redirect(url_for("pedido_confirmado", codigo=codigo))
        return render_template("checkout.html", puesto=puesto, items=items, total=total)

    @app.get("/pedido/<codigo>")
    def pedido_confirmado(codigo):
        if codigo not in session.get("mis_pedidos", []):
            abort(404)
        pedido = db().execute("""SELECT ped.*, pt.nombre puesto, co.nombre comercio,
          co.direccion, co.colonia, co.alcaldia, u.nombre vendedor, u.apellidos vendedor_apellidos,
          u.telefono whatsapp_telefono, u.whatsapp_publico
          FROM pedidos ped JOIN puestos pt ON pt.id=ped.puesto_id
          JOIN comercios co ON co.id=pt.comercio_id JOIN usuarios u ON u.id=pt.vendedor_id
          WHERE ped.codigo=?""", (codigo,)).fetchone()
        if not pedido:
            abort(404)
        items = db().execute("SELECT * FROM pedido_items WHERE pedido_id=?", (pedido["id"],)).fetchall()
        texto = (f"Hola, soy {pedido['comprador']}. Confirmé el pedido {pedido['codigo']} "
                 f"en {pedido['puesto']} mediante Chilantianguis. "
                 f"Modalidad: {pedido['modalidad'].replace('_', ' ')}. "
                 f"Total: {dinero(pedido['total_centavos'])}. ¿Me ayudas a coordinarlo?")
        wa_url = enlace_whatsapp(pedido["whatsapp_telefono"], pedido["whatsapp_publico"], texto)
        return render_template("pedido_confirmado.html", pedido=pedido, items=items, whatsapp_url=wa_url)

    @app.post("/pedidos/<int:id_pedido>/estado")
    @requiere_login("comerciante")
    def pedido_cambiar_estado(id_pedido):
        nuevo = request.form.get("estado")
        if nuevo not in ("preparando", "listo", "entregado", "cancelado"):
            abort(400, "Estado no permitido")
        con = db()
        try:
            con.execute("BEGIN IMMEDIATE")
            pedido = con.execute("""SELECT ped.* FROM pedidos ped JOIN puestos pt ON pt.id=ped.puesto_id
              WHERE ped.id=? AND pt.vendedor_id=?""", (id_pedido, g.user["id"])).fetchone()
            if not pedido:
                con.rollback()
                abort(403)
            if pedido["estado"] in ("cancelado", "entregado"):
                con.rollback()
                abort(400, "Un pedido cerrado no se puede volver a modificar")
            if nuevo == "cancelado":
                for linea in con.execute("SELECT producto_id,cantidad FROM pedido_items WHERE pedido_id=?", (id_pedido,)).fetchall():
                    con.execute("UPDATE productos SET stock=stock+? WHERE id=?", (linea["cantidad"], linea["producto_id"]))
            con.execute("UPDATE pedidos SET estado=? WHERE id=?", (nuevo, id_pedido))
            con.commit()
        except sqlite3.Error:
            con.rollback()
            raise
        flash("Estado del pedido actualizado.", "success")
        return redirect(url_for("panel"))

    def ficha_mayoreo(id_grupo):
        return db().execute("""SELECT g.*, u.nombre creador,
          COALESCE((SELECT SUM(a.cantidad) FROM aportaciones_mayoreo a
                    WHERE a.grupo_id=g.id),0) AS comprometido,
          (SELECT COUNT(*) FROM aportaciones_mayoreo a
           WHERE a.grupo_id=g.id AND a.cantidad>0) AS participantes
          FROM grupos_mayoreo g JOIN usuarios u ON u.id=g.creador_id
          WHERE g.id=?""", (id_grupo,)).fetchone()

    @app.get("/mayoreo")
    @requiere_login("comerciante")
    def mayoreo_lista():
        grupos = db().execute("""SELECT g.*, u.nombre creador,
          COALESCE((SELECT SUM(a.cantidad) FROM aportaciones_mayoreo a
                    WHERE a.grupo_id=g.id),0) AS comprometido,
          (SELECT COUNT(*) FROM aportaciones_mayoreo a
                    WHERE a.grupo_id=g.id AND a.cantidad>0) AS participantes
          FROM grupos_mayoreo g JOIN usuarios u ON u.id=g.creador_id
          ORDER BY CASE g.estado WHEN 'abierto' THEN 0 WHEN 'completo' THEN 1 ELSE 2 END,
                   g.id DESC""").fetchall()
        return render_template("mayoreo_lista.html", grupos=grupos)

    @app.route("/mayoreo/nuevo", methods=["GET", "POST"])
    @requiere_login("comerciante")
    def mayoreo_nuevo():
        if request.method == "POST":
            try:
                proveedor = request.form.get("proveedor", "").strip()
                producto = request.form.get("producto", "").strip()
                unidad = request.form.get("unidad", "")
                descripcion = request.form.get("descripcion", "").strip()[:1000]
                precio = Decimal(request.form.get("precio_unitario", ""))
                cents = int((precio * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                cantidad = int(request.form.get("cantidad_objetivo", ""))
                fecha_limite = request.form.get("fecha_limite", "")
                fecha = datetime.strptime(fecha_limite, "%Y-%m-%d").date()
                if not (3 <= len(proveedor) <= 120 and 3 <= len(producto) <= 120):
                    raise ValueError("Indica proveedor y producto de al menos 3 caracteres.")
                if unidad not in UNIDADES or not 1 <= cents <= 100000000:
                    raise ValueError("Selecciona una unidad y un precio válido.")
                if not 2 <= cantidad <= 100000 or cents * cantidad > 100000000000:
                    raise ValueError("La meta debe ser de 2 a 100,000 unidades, con monto válido.")
                if fecha < datetime.now(TZ).date():
                    raise ValueError("La fecha límite no puede ser anterior a hoy.")
            except (ValueError, InvalidOperation, OverflowError) as exc:
                flash(str(exc) if isinstance(exc, ValueError) else "Revisa los datos numéricos.", "error")
                return redirect(url_for("mayoreo_nuevo"))
            with db():
                cur = db().execute("""INSERT INTO grupos_mayoreo
                    (creador_id,proveedor,producto,descripcion,unidad,
                     precio_unitario_centavos,cantidad_objetivo,fecha_limite)
                    VALUES(?,?,?,?,?,?,?,?)""",
                    (g.user["id"], proveedor, producto, descripcion, unidad,
                     cents, cantidad, fecha_limite))
                db().execute("""INSERT INTO aportaciones_mayoreo
                    (grupo_id,comerciante_id,cantidad,monto_centavos) VALUES(?,?,0,0)""",
                    (cur.lastrowid, g.user["id"]))
            flash("Grupo creado. Comparte la liga con otros comerciantes registrados.", "success")
            return redirect(url_for("mayoreo_detalle", id_grupo=cur.lastrowid))
        return render_template("mayoreo_nuevo.html", unidades=UNIDADES,
                               fecha_min=datetime.now(TZ).date().isoformat())

    @app.get("/mayoreo/<int:id_grupo>")
    @requiere_login("comerciante")
    def mayoreo_detalle(id_grupo):
        grupo = ficha_mayoreo(id_grupo)
        if not grupo:
            abort(404)
        aportaciones = db().execute("""SELECT a.*, u.nombre, u.apellidos
            FROM aportaciones_mayoreo a JOIN usuarios u ON u.id=a.comerciante_id
            WHERE a.grupo_id=? ORDER BY a.cantidad DESC, a.id""", (id_grupo,)).fetchall()
        mia = next((a for a in aportaciones if a["comerciante_id"] == g.user["id"]), None)
        return render_template("mayoreo_detalle.html", grupo=grupo, aportaciones=aportaciones,
                               mia=mia, hoy=datetime.now(TZ).date().isoformat())

    @app.post("/mayoreo/<int:id_grupo>/aportar")
    @requiere_login("comerciante")
    def mayoreo_aportar(id_grupo):
        try:
            cantidad = int(request.form.get("cantidad", ""))
            if not 1 <= cantidad <= 100000:
                raise ValueError("Indica de 1 a 100,000 unidades para aportar.")
        except ValueError:
            flash("Cantidad inválida para el aporte.", "error")
            return redirect(url_for("mayoreo_detalle", id_grupo=id_grupo))
        conn = db()
        try:
            conn.execute("BEGIN IMMEDIATE")
            grupo = ficha_mayoreo(id_grupo)
            if not grupo:
                abort(404)
            if grupo["estado"] != "abierto" or grupo["fecha_limite"] < datetime.now(TZ).date().isoformat():
                raise ValueError("Este grupo ya no admite aportaciones.")
            restante = grupo["cantidad_objetivo"] - grupo["comprometido"]
            if cantidad > restante:
                raise ValueError(f"Solo quedan {restante} {grupo['unidad']} disponibles para completar la meta.")
            monto = cantidad * grupo["precio_unitario_centavos"]
            conn.execute("""INSERT INTO aportaciones_mayoreo
                (grupo_id,comerciante_id,cantidad,monto_centavos) VALUES(?,?,?,?)
                ON CONFLICT(grupo_id,comerciante_id) DO UPDATE SET
                  cantidad=cantidad+excluded.cantidad,
                  monto_centavos=monto_centavos+excluded.monto_centavos""",
                (id_grupo, g.user["id"], cantidad, monto))
            if cantidad == restante:
                conn.execute("UPDATE grupos_mayoreo SET estado='completo' WHERE id=?", (id_grupo,))
            conn.commit()
            flash("Aportación comprometida. No se cobró dinero real.", "success")
        except (ValueError, sqlite3.Error) as exc:
            conn.rollback()
            flash(str(exc), "warning")
        return redirect(url_for("mayoreo_detalle", id_grupo=id_grupo))

    from solicitudes import registrar
    registrar(app, ALCALDIAS)
    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
