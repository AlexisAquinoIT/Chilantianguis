"""Ejecuta desde carpeta Chilantiaguis: python scripts/activar_stock_demo.py.
Solo da existencias a productos de EJEMPLO: nunca toca mercancía de usuarios.
"""
from pathlib import Path
import sqlite3
BASE=Path(__file__).resolve().parent.parent
DB=BASE/'instance'/'chilantiaguis.sqlite3'
with sqlite3.connect(DB) as con:
    c=con.execute("""UPDATE productos SET stock=15 WHERE stock=0 AND id IN (
        SELECT p.id FROM productos p JOIN puestos pt ON pt.id=p.puesto_id
        JOIN comercios co ON co.id=pt.comercio_id WHERE co.origen='demo'
    )""")
    print(f"Productos ficticios con stock de demostración activado: {c.rowcount}")
    print("Advertencia: nunca usar stock ficticio como inventario real.")
