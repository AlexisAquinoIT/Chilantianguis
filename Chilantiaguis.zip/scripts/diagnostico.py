"""Diagnóstico de solo lectura: verifica la base activa de Chilantianguis."""
from pathlib import Path
import sqlite3

BASE = Path(__file__).resolve().parent.parent
DB = BASE / 'instance' / 'chilantiaguis.sqlite3'

print(f'Proyecto: {BASE}')
print(f'Archivo SQLite activo: {DB}')
if not DB.is_file():
    print('NO SE ENCONTRO LA BASE. No ejecutes cargas hasta comprobar si estás en la carpeta correcta.')
else:
    conexion = sqlite3.connect(f'{DB.as_uri()}?mode=ro', uri=True)
    try:
        for nombre in ('comercios', 'puestos', 'productos', 'usuarios', 'pedidos', 'grupos_mayoreo'):
            if conexion.execute('SELECT 1 FROM sqlite_master WHERE type="table" AND name=?', (nombre,)).fetchone():
                print(f'{nombre}: {conexion.execute(f"SELECT COUNT(*) FROM {nombre}").fetchone()[0]}')
            else:
                print(f'{nombre}: tabla aún no creada')
        print('Consulta solo lectura: no se ha cambiado ningún dato.')
    finally:
        conexion.close()
