/** Compilar Tailwind CSS en un archivo local (opcional para desarrolladores).
 * Ejecutar: npm install --no-save tailwindcss@4 && node scripts/build_css.js
 * El archivo compilado ya se incluye en el proyecto, por lo que Node NO es necesario
 * para iniciar Flask.
 */
const fs = require('fs');
const path = require('path');
const { compile } = require('tailwindcss');
const root = path.join(__dirname, '..');
const moduleRoot = path.dirname(require.resolve('tailwindcss/package.json'));
const candidates = new Set();
for (const dir of ['templates', 'static/js']) {
  const base = path.join(root, dir);
  for (const file of fs.readdirSync(base)) {
    const filename = path.join(base, file);
    if (!fs.statSync(filename).isFile()) continue;
    if (!/\.(html|js)$/.test(file)) continue;
    const source = fs.readFileSync(filename, 'utf8');
    // Los nombres estáticos en las plantillas y en JS de DOM.
    for (const m of source.matchAll(/(?:class|className)\s*=\s*["'`]([^"'`]+)["'`]/g)) {
      m[1].split(/\s+/).forEach(x => candidates.add(x.trim()));
    }
    // Utilidades presentes dentro de expresiones Jinja y cadenas de JS.
    for (const word of source.matchAll(/(?:bg|text|border|ring|hover:bg|hover:text|hover:border)-(?:slate|emerald|orange|rose|amber|white|black|gray)-[0-9]+(?:\/[0-9]+)?/g)) {
      candidates.add(word[0]);
    }
  }
}
const stylesheet = fs.readFileSync(path.join(moduleRoot, 'theme.css'), 'utf8') + '\n' +
  fs.readFileSync(path.join(moduleRoot, 'preflight.css'), 'utf8') + '\n@tailwind utilities;';
(async () => {
  const result = await compile(stylesheet);
  const css = result.build([...candidates]);
  const out = path.join(root, 'static', 'css', 'tailwind_compilado.css');
  fs.writeFileSync(out, css, 'utf8');
  console.log(`Tailwind compilado: ${out} (${Math.round(css.length / 1024)} KB / ${candidates.size} candidatos).`);
})().catch(err => { console.error(err); process.exit(1); });
