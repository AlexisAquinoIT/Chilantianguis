"""Añade asociaciones ficticias y remates activos de ejemplo sin duplicar."""
from pathlib import Path
import sys
import sqlite3
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0,str(BASE))
from solicitudes import migrar
DB = BASE/'instance'/'chilantiaguis.sqlite3'

def main():
    con=sqlite3.connect(DB)
    con.row_factory=sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    migrar(con)
    now=datetime.now(ZoneInfo('America/Mexico_City'))
    start=(now-timedelta(hours=1)).strftime('%Y-%m-%dT%H:%M')
    end=(now+timedelta(days=3)).strftime('%Y-%m-%dT%H:%M')
    n=0; r=0
    with con:
        for c in con.execute("SELECT id,nombre FROM comercios WHERE tipo='tianguis' AND origen='demo'").fetchall():
            nombre='Asociación de Comerciantes de '+c['nombre'].replace('Tianguis de ','').replace('Tianguis ','')+' (DEMO; no verificada)'
            con.execute('UPDATE comercios SET asociacion_responsable=? WHERE id=? AND (asociacion_responsable IS NULL OR asociacion_responsable="")',(nombre,c['id']))
            n+=1
        # Remates ficticios en cuatro tianguis, con productos de prueba.
        for nombre in ('Tianguis de la Lagunilla','Tianguis Nápoles','Tianguis de Santa Cruz Meyehualco','Tianguis de Nativitas'):
            p=con.execute('''SELECT p.id FROM productos p JOIN puestos pt ON pt.id=p.puesto_id JOIN comercios c ON c.id=pt.comercio_id WHERE c.nombre=? AND c.origen='demo' ORDER BY p.id LIMIT 1''',(nombre,)).fetchone()
            if not p: continue
            existe=con.execute('SELECT 1 FROM remates WHERE producto_id=? AND fin>? LIMIT 1',(p['id'],start)).fetchone()
            if not existe:
                con.execute('INSERT INTO remates(producto_id,descuento,inicio,fin) VALUES(?,?,?,?)',(p['id'],25,start,end))
                r+=1
    con.close()
    print(f'Asociaciones ilustrativas: {n}. Remates de demostración nuevos: {r}.')
    print('Los remates duran 3 días desde la ejecución; no representan ofertas reales.')
if __name__=='__main__': main()
