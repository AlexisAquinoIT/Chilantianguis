"""Precarga 64 referencias del equipo para Chilantiaguis.

IMPORTANTE: ubicaciones aproximadas, horarios y puestos NO VERIFICADOS.
Las tiendas y pequeños negocios son ejemplos inventados por el equipo.
No se sobrescriben registros reales ni información de comerciantes.
Ejecutar desde la carpeta Chilantiaguis: python scripts/cargar_64_comercios.py
"""
from pathlib import Path
from collections import Counter
import secrets
import sqlite3
from werkzeug.security import generate_password_hash

BASE = Path(__file__).resolve().parent.parent
DB = BASE / "instance" / "chilantiaguis.sqlite3"

# Formato: (tipo, nombre, colonia, referencia, latitud, longitud)
# Las coordenadas son aproximaciones de la zona, NO de cada puerta o puesto.
LUGARES = {
    "Álvaro Obregón": [
        ("tianguis", "Tianguis de La Banderita", "San Ángel", "Zona de San Ángel", 19.3459, -99.1905),
        ("mercado", "Mercado Melchor Múzquiz", "San Ángel", "Col. San Ángel", 19.3475, -99.1900),
        ("tienda", 'Abarrotes "La Esperanza"', "Plateros", "Col. Plateros", 19.3642, -99.2190),
        ("negocio", 'Papelería "El Iris"', "Alfonso XIII", "Col. Alfonso XIII", 19.3835, -99.1946),
    ],
    "Azcapotzalco": [
        ("tianguis", "Tianguis de la Providencia", "Providencia", "Col. Providencia", 19.4966, -99.1734),
        ("mercado", "Mercado Azcapotzalco", "Centro de Azcapotzalco", "Centro de Azcapotzalco", 19.4841, -99.1827),
        ("tienda", 'Miscelánea "San Juan"', "San Juan Tlihuaca", "Col. San Juan Tlihuaca", 19.4898, -99.2043),
        ("negocio", 'Tlapalería "Hermanos Pérez"', "Clavería", "Col. Clavería", 19.4634, -99.1868),
    ],
    "Benito Juárez": [
        ("tianguis", "Tianguis Nápoles", "Nápoles", "Calle Filadelfia y Dakota, Col. Nápoles", 19.3933, -99.1784),
        ("mercado", "Mercado Portales", "San Simón", "Calz. Santa Cruz, Col. San Simón", 19.3601, -99.1454),
        ("tienda", 'Abarrotes "Don Pepe"', "Del Valle Centro", "Col. Del Valle Centro", 19.3890, -99.1658),
        ("negocio", 'Tintorería "Limpia y Rápida"', "Narvarte", "Col. Narvarte", 19.3941, -99.1534),
    ],
    "Coyoacán": [
        ("tianguis", "Tianguis de la Bola", "Ajusco", "Col. Ajusco", 19.3149, -99.1631),
        ("mercado", "Mercado de Coyoacán", "Del Carmen", "Ignacio Allende s/n, Del Carmen", 19.3491, -99.1622),
        ("tienda", 'Miscelánea "Los Tres Potrillos"', "Pedregal de Santo Domingo", "Col. Pedregal de Santo Domingo", 19.3222, -99.1524),
        ("negocio", 'Panadería artesanal "La Coyoacanense"', "Centro de Coyoacán", "Centro de Coyoacán", 19.3500, -99.1614),
    ],
    "Cuajimalpa de Morelos": [
        ("tianguis", "Tianguis Cuajimalpa Centro", "Cuajimalpa Centro", "Calle Veracruz", 19.3576, -99.2997),
        ("mercado", "Mercado Cuajimalpa", "Cuajimalpa Centro", "Av. Juárez, Centro", 19.3571, -99.2980),
        ("tienda", 'Abarrotes "El Manantial"', "San Pedro Cuajimalpa", "Pueblo San Pedro Cuajimalpa", 19.3598, -99.2961),
        ("negocio", 'Ferretería "La Principal"', "Contadero", "Col. Contadero", 19.3458, -99.2915),
    ],
    "Cuauhtémoc": [
        ("tianguis", "Tianguis de la Lagunilla", "Lagunilla", "Eje 1 Norte y Comonfort", 19.4470, -99.1393),
        ("mercado", "Mercado de San Juan", "Centro Histórico", "Ernesto Pugibet, Centro Histórico", 19.4301, -99.1427),
        ("tienda", 'Minisuper "La Roma"', "Roma Norte", "Col. Roma Norte", 19.4197, -99.1632),
        ("negocio", 'Sastrería "El Buen Vestir"', "Doctores", "Col. Doctores", 19.4195, -99.1447),
    ],
    "Gustavo A. Madero": [
        ("tianguis", "Tianguis de la San Felipe de Jesús", "San Felipe de Jesús", "Av. Villa de Ayala", 19.4923, -99.0686),
        ("mercado", "Mercado Río Blanco", "Río Blanco", "Congreso de la Unión y Oriente 91", 19.4695, -99.1167),
        ("tienda", 'Abarrotes "La Providencia"', "Lindavista", "Col. Lindavista", 19.4982, -99.1334),
        ("negocio", 'Cerrajería "Llaves GAM"', "Industrial", "Col. Industrial", 19.4774, -99.1163),
    ],
    "Iztacalco": [
        ("tianguis", "Tianguis Apatlaco", "Apatlaco", "Eje 3 Oriente y Apatlaco", 19.3811, -99.1074),
        ("mercado", "Mercado Pantitlán", "Agrícola Pantitlán", "Calle 6, Col. Agrícola Pantitlán", 19.4126, -99.0713),
        ("tienda", 'Miscelánea "La Guadalupana"', "Agrícola Oriental", "Col. Agrícola Oriental", 19.3991, -99.0805),
        ("negocio", 'Estética "Look Express"', "Granjas México", "Col. Granjas México", 19.3908, -99.1007),
    ],
    "Iztapalapa": [
        ("tianguis", "Tianguis de Santa Cruz Meyehualco", "Santa Cruz Meyehualco", "Av. Guelatao", 19.3454, -99.0390),
        ("mercado", "Mercado Escuadrón 201", "Escuadrón 201", "Av. 5 y Rodolfo Usigli", 19.3702, -99.1112),
        ("tienda", 'Abarrotes "El Güero"', "Desarrollo Urbano Quetzalcóatl", "Col. Desarrollo Urbano Quetzalcóatl", 19.3216, -99.0507),
        ("negocio", 'Taller Mecánico "Los Ángeles"', "Barrio San Lucas", "Barrio San Lucas", 19.3489, -99.0946),
    ],
    "La Magdalena Contreras": [
        ("tianguis", "Tianguis de San Bernabé", "San Bernabé Ocotepec", "Av. San Bernabé Ocotepec", 19.3184, -99.2591),
        ("mercado", "Mercado La Magdalena", "La Magdalena", "Camino Real a Contreras", 19.3073, -99.2411),
        ("tienda", 'Miscelánea "El Charquito"', "San Jerónimo Aculco", "Col. San Jerónimo Aculco", 19.3243, -99.2299),
        ("negocio", 'Carpintería "San José"', "Pueblo Nuevo Alto", "Pueblo Nuevo Alto", 19.3071, -99.2518),
    ],
    "Miguel Hidalgo": [
        ("tianguis", "Tianguis de Polanco", "Polanco", "Parque Lincoln (sábados)", 19.4301, -99.1985),
        ("mercado", "Mercado de Tacuba", "Tacuba", "Golfo de los Mosquitos s/n", 19.4596, -99.1897),
        ("tienda", 'Abarrotes "La Escandón"', "Escandón", "Col. Escandón", 19.4029, -99.1825),
        ("negocio", 'Lavandería "Burbujas"', "Anáhuac", "Col. Anáhuac", 19.4458, -99.1751),
    ],
    "Milpa Alta": [
        ("tianguis", "Tianguis de Villa Milpa Alta", "Villa Milpa Alta", "Plaza de la Corregidora", 19.1920, -99.0228),
        ("mercado", "Mercado San Pedro Atocpan", "San Pedro Atocpan", "Plaza San Martín", 19.2016, -99.0480),
        ("tienda", 'Miscelánea "La Frontera"', "San Antonio Tecómitl", "Pueblo San Antonio Tecómitl", 19.2180, -98.9902),
        ("negocio", 'Productora de Mole "Don Pancho"', "San Pedro Atocpan", "San Pedro Atocpan", 19.2041, -99.0500),
    ],
    "Tláhuac": [
        ("tianguis", "Tianguis de San Francisco Tlaltenco", "San Francisco Tlaltenco", "Av. Tláhuac", 19.2958, -99.0071),
        ("mercado", "Mercado de Zapotitlán", "Santiago Zapotitlán", "Av. Guillermo Prieto", 19.2967, -99.0407),
        ("tienda", 'Abarrotes "Los Hermanos"', "La Draga", "Col. La Draga", 19.2845, -99.0209),
        ("negocio", 'Papelería "Tláhuac Escolar"', "Barrio San Miguel", "Barrio San Miguel", 19.2842, -99.0070),
    ],
    "Tlalpan": [
        ("tianguis", "Tianguis de la Colonia Toriello Guerra", "Toriello Guerra", "Calle Cuitláhuac", 19.2935, -99.1677),
        ("mercado", "Mercado La Paz", "Centro de Tlalpan", "Centro de Tlalpan", 19.2883, -99.1681),
        ("tienda", 'Miscelánea "El Bosque"', "Héroes de Padierna", "Col. Héroes de Padierna", 19.3102, -99.2207),
        ("negocio", 'Vulcanizadora "Ruta Sur"', "San Pedro Mártir", "Pueblo de San Pedro Mártir", 19.2586, -99.1717),
    ],
    "Venustiano Carranza": [
        ("tianguis", "Tianguis Balbuena", "Jardín Balbuena", "Retorno 13 y Av. del Taller", 19.4131, -99.1046),
        ("mercado", "Mercado de Sonora", "Merced Balbuena", "Fray Servando Teresa de Mier 419", 19.4234, -99.1223),
        ("tienda", 'Abarrotes "La Esquina"', "Jardín Balbuena", "Col. Jardín Balbuena", 19.4181, -99.1074),
        ("negocio", 'Refaccionaria "Carranza"', "Moctezuma", "Col. Moctezuma", 19.4324, -99.0941),
    ],
    "Xochimilco": [
        ("tianguis", "Tianguis de Nativitas", "Nativitas", "Camino a Nativitas", 19.2442, -99.0979),
        ("mercado", "Mercado de Xochimilco", "Centro de Xochimilco", "Av. Nuevo León, Centro", 19.2564, -99.1037),
        ("tienda", 'Miscelánea "Las Flores"', "Barrio Xaltocan", "Barrio Xaltocan", 19.2513, -99.1113),
        ("negocio", "Taller de reparación de Trajineras", "Barrio Caltongo", "Barrio Caltongo", 19.2482, -99.0990),
    ],
}

# Lunes=0 ... Domingo=6. TODOS ESTOS HORARIOS SON ILUSTRATIVOS.
DIAS_TIANGUIS = [5, 3, 5, 6, 2, 6, 6, 3, 5, 6, 5, 6, 2, 5, 3, 6]
HORAS = {"tianguis": ("08:00", "16:00"), "mercado": ("08:00", "18:00"),
         "tienda": ("08:00", "21:00"), "negocio": ("09:00", "19:00")}

# (nombre de puesto DEMO, nombre de producto DEMO, categoría, precio centavos)
CATALOGO = {
    "tianguis": [
        ("Frutas y verduras · ejemplo", "Jitomate 1 kg · ejemplo", "Frutas y verduras", 2800),
        ("Antojitos · ejemplo", "Quesadilla · ejemplo", "Comida preparada", 3500),
        ("Ropa popular · ejemplo", "Playera · ejemplo", "Ropa y calzado", 9500),
    ],
    "mercado": [
        ("Verdulería · ejemplo", "Papa 1 kg · ejemplo", "Frutas y verduras", 3000),
        ("Cocina económica · ejemplo", "Comida corrida · ejemplo", "Comida preparada", 10500),
    ],
    "tienda": [
        ("Mostrador de abarrotes · ejemplo", "Arroz 1 kg · ejemplo", "Abarrotes", 3600),
    ],
}

def negocio_demo(nombre):
    lower = nombre.lower()
    if "papeler" in lower:
        return ("Papelería · ejemplo", "Cuaderno · ejemplo", "Otros", 4500)
    if "ferreter" in lower or "tlapaler" in lower:
        return ("Ferretería · ejemplo", "Cinta aislante · ejemplo", "Hogar", 2500)
    if "panader" in lower:
        return ("Panadería · ejemplo", "Concha · ejemplo", "Comida preparada", 2000)
    if "mole" in lower:
        return ("Mole artesanal · ejemplo", "Mole 250 g · ejemplo", "Abarrotes", 8500)
    if "refaccion" in lower:
        return ("Refaccionaria · ejemplo", "Foco automotriz · ejemplo", "Otros", 7500)
    if "trajiner" in lower:
        return ("Reparación de trajineras · ejemplo", "Servicio básico · ejemplo", "Otros", 25000)
    if "tintorer" in lower or "lavander" in lower:
        return ("Lavado · ejemplo", "Servicio por prenda · ejemplo", "Otros", 8500)
    if "taller" in lower or "vulcaniz" in lower:
        return ("Servicio automotriz · ejemplo", "Revisión básica · ejemplo", "Otros", 15000)
    if "estética" in lower:
        return ("Estética · ejemplo", "Corte de cabello · ejemplo", "Otros", 12000)
    if "sastrer" in lower:
        return ("Sastrería · ejemplo", "Ajuste de prenda · ejemplo", "Otros", 9000)
    if "carpinter" in lower:
        return ("Carpintería · ejemplo", "Reparación simple · ejemplo", "Hogar", 15000)
    return ("Servicios · ejemplo", "Servicio ilustrativo", "Otros", 10000)

def cargar():
    DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB)
    con.execute("PRAGMA foreign_keys = ON")
    try:
        # Crea las tablas si no existen, sin eliminar datos actuales.
        con.executescript((BASE / "schema.sql").read_text(encoding="utf-8"))
        with con:
            for categoria in {"Frutas y verduras", "Comida preparada", "Ropa y calzado", "Abarrotes", "Otros", "Hogar"}:
                con.execute("INSERT OR IGNORE INTO categorias(nombre) VALUES (?)", (categoria,))

            # Cuenta técnica de demostración, sin contraseña publicada.
            email = "catalogo-chilantiaguis@ejemplo.invalid"
            con.execute("INSERT OR IGNORE INTO usuarios(nombre,email,password_hash,rol) VALUES(?,?,?,'comerciante')",
                        ("Catálogo ilustrativo (sin verificar)", email,
                         generate_password_hash(secrets.token_urlsafe(32))))
            usuario_id = con.execute("SELECT id FROM usuarios WHERE email=?", (email,)).fetchone()[0]

            # Quitar SOLO las seis muestras genéricas de la primera versión.
            con.execute("""DELETE FROM comercios WHERE origen='demo' AND nombre IN
                ('Tianguis de muestra · Centro', 'Mercado público de muestra · Roma',
                 'Abarrotes de muestra · Iztapalapa', 'Panadería de muestra · Coyoacán',
                 'Tianguis de muestra · Xochimilco', 'Mercado público de muestra · GAM')""")

            agregados = 0
            saltados = 0
            for num_alcaldia, (alcaldia, sitios) in enumerate(LUGARES.items()):
                for tipo, nombre, colonia, referencia, lat, lng in sitios:
                    existe = con.execute("""SELECT id FROM comercios
                        WHERE nombre=? COLLATE NOCASE AND tipo=? AND alcaldia=? LIMIT 1""",
                        (nombre, tipo, alcaldia)).fetchone()
                    if existe:
                        saltados += 1
                        continue
                    if tipo in ("tianguis", "mercado"):
                        descripcion = ("Nombre y referencia proporcionados por el equipo. "
                                       "Coordenadas, días, horarios, puestos y precios ilustrativos; verificar con el establecimiento.")
                    else:
                        descripcion = ("Negocio ficticio creado para demostrar Chilantiaguis. "
                                       "Ubicación aproximada, horarios, puestos y precios inventados.")
                    cid = con.execute("""INSERT INTO comercios
                        (nombre,tipo,descripcion,alcaldia,colonia,direccion,lat,lng,origen,verificado)
                        VALUES (?,?,?,?,?,?,?,?, 'demo',0)""",
                        (nombre, tipo, descripcion, alcaldia, colonia,
                         "Referencia aproximada: " + referencia, lat, lng)).lastrowid
                    dias = ([DIAS_TIANGUIS[num_alcaldia]] if tipo == "tianguis" else
                            list(range(7)) if tipo in ("mercado", "tienda") else list(range(6)))
                    inicio, fin = HORAS[tipo]
                    con.executemany("""INSERT INTO horarios(comercio_id,dia,inicio,fin)
                        VALUES(?,?,?,?)""", [(cid, d, inicio, fin) for d in dias])

                    productos = CATALOGO.get(tipo, [negocio_demo(nombre)])
                    for puesto_nombre, producto_nombre, categoria, precio in productos:
                        pid = con.execute("""INSERT INTO puestos
                            (comercio_id,vendedor_id,nombre,descripcion,referencia)
                            VALUES (?,?,?,?,?)""",
                            (cid, usuario_id, puesto_nombre,
                             "Puesto de demostración, NO corresponde a un comerciante confirmado.",
                             "Ubicación dentro del comercio no verificada")).lastrowid
                        cat_id = con.execute("SELECT id FROM categorias WHERE nombre=?", (categoria,)).fetchone()[0]
                        con.execute("""INSERT INTO productos
                            (puesto_id,categoria_id,nombre,descripcion,precio_centavos)
                            VALUES (?,?,?,?,?)""",
                            (pid, cat_id, producto_nombre,
                             "Producto y precio de demostración; no es una oferta comercial real.", precio))
                    agregados += 1
        cuenta = con.execute("SELECT tipo, COUNT(*) FROM comercios GROUP BY tipo").fetchall()
        print(f"Listo: {agregados} comercios agregados; {saltados} existentes no duplicados.")
        print("Total en tu base por tipo:", dict(cuenta))
        print("ATENCIÓN: horarios, puntos, puestos y precios son de ejemplo y NO están verificados.")
        print("Abre /explorar y actualiza con Ctrl+F5.")
    finally:
        con.close()

if __name__ == "__main__":
    assert len(LUGARES) == 16 and all(len(sitios) == 4 for sitios in LUGARES.values())
    assert Counter(sitio[0] for sitios in LUGARES.values() for sitio in sitios) == Counter(
        {"tianguis": 16, "mercado": 16, "tienda": 16, "negocio": 16})
    cargar()
