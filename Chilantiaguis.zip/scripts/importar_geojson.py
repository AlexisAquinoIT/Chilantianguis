"""Importador conservador de GeoJSON (SEDECO / datos abiertos CDMX).

Ejemplos desde raíz del proyecto:
  python scripts/importar_geojson.py descargas/tianguis.geojson --tipo tianguis
  python scripts/importar_geojson.py descargas/mercados.geojson --tipo mercado
  python scripts/importar_geojson.py descargas/tianguis.geojson --tipo tianguis --nombre nombre --alcaldia alcaldia

No inventa horarios, precios ni vendedores. Marca origen como 'datos_abiertos'.
Admite geometría Point, MultiPoint, LineString, Polygon y MultiPolygon:
para geometrías extensas usa su centro promedio aproximado, NO su límite.
"""
import argparse
import json
import sqlite3
import sys
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def norm(value):
    text = unicodedata.normalize('NFKD', str(value).strip())
    return ''.join(char for char in text if not unicodedata.combining(char)).lower().replace(' ', '_')


def first(props, candidates, extra=None):
    index = {norm(k): v for k, v in props.items()}
    for key in ([extra] if extra else []) + list(candidates):
        if key and index.get(norm(key)) not in (None, ''):
            return str(index[norm(key)]).strip()
    return ''


def points(coords):
    if not isinstance(coords, list) or not coords:
        return
    if isinstance(coords[0], (int, float)) and len(coords) >= 2:
        yield float(coords[0]), float(coords[1])
    else:
        for part in coords:
            yield from points(part)


def center(feature):
    geometry = feature.get('geometry') or {}
    xs = list(points(geometry.get('coordinates', [])))
    if not xs:
        return None
    lng = sum(x for x, _ in xs) / len(xs)
    lat = sum(y for _, y in xs) / len(xs)
    if not (19.0 <= lat <= 20.0 and -100 <= lng <= -98):
        return None
    return round(lat, 6), round(lng, 6)


def importar(path, tipo, db_path, campo_nombre=None, campo_alcaldia=None, dry_run=False):
    source = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    entries = source.get('features', []) if source.get('type') == 'FeatureCollection' else []
    if not entries:
        raise ValueError('El archivo debe ser un GeoJSON FeatureCollection con features.')
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    try:
        if not conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='comercios'").fetchone():
            raise ValueError('Base de datos vacía: inicia Flask una vez antes de importar.')
        existing = {(r['tipo'], norm(r['nombre']), round(r['lat'], 4), round(r['lng'], 4))
                    for r in conn.execute('SELECT tipo,nombre,lat,lng FROM comercios')}
        sample = {}
        written, invalid, duplicates = 0, 0, 0
        for num, feature in enumerate(entries, 1):
            props = feature.get('properties') or {}
            if num == 1:
                sample = props
            c = center(feature)
            name = first(props, ['nombre', 'nombre_tianguis', 'nombre_del_tianguis', 'tianguis', 'nomb_tiang', 'nom_tiang', 'nombre_comercial',
                                 'nombre_mercado', 'nom_mercado', 'mercado', 'nom_comercio',
                                 'razon_social', 'nom_estab', 'nom', 'name'], campo_nombre)
            alcaldia = first(props, ['alcaldia', 'municipio', 'nom_alc', 'nom_mun', 'demarcacion', 'alcaldia_1', 'cve_alcaldia',
                                     'nombre_alcaldia', 'alcaldia_municipio'], campo_alcaldia)
            colonia = first(props, ['colonia', 'asentamiento', 'nom_colonia'])
            direccion = first(props, ['direccion', 'ubicacion', 'calle', 'domicilio', 'ubicacion_tianguis', 'calle_ubicacion'])
            if c is None or not alcaldia:
                invalid += 1
                continue
            # Algunos padrones solo proporcionan la ubicación, no el nombre propio.
            # El título genérico no debe atribuirse como nombre comercial verificado.
            if not name:
                lugar = colonia or direccion or f'registro {num}'
                name = f'{"Tianguis" if tipo == "tianguis" else "Mercado"} registrado · {lugar}'
            lat, lng = c
            key = tipo, norm(name), round(lat, 4), round(lng, 4)
            if key in existing:
                duplicates += 1
                continue
            existing.add(key)
            if not dry_run:
                conn.execute('''INSERT INTO comercios
                  (nombre,tipo,descripcion,alcaldia,colonia,direccion,lat,lng,origen,verificado)
                  VALUES(?,?,?,?,?,?,?,?,'datos_abiertos',0)''',
                  (name[:120], tipo,
                   'Ubicación de referencia proveniente de un conjunto de datos abiertos. Horarios, precios y puestos pendientes de confirmación.',
                   alcaldia[:100], colonia[:100], (direccion or 'Ubicación aproximada: validar antes de visitar')[:250], lat, lng))
            written += 1
        if dry_run:
            conn.rollback()
        else:
            conn.commit()
        return written, duplicates, invalid, list(sample.keys())
    finally:
        conn.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('geojson', type=Path)
    parser.add_argument('--tipo', required=True, choices=['tianguis', 'mercado'])
    parser.add_argument('--db', type=Path, default=ROOT / 'instance' / 'chilantiaguis.sqlite3')
    parser.add_argument('--nombre', help='Nombre exacto de la propiedad GeoJSON con nombre del lugar')
    parser.add_argument('--alcaldia', help='Nombre exacto de la propiedad con alcaldía')
    parser.add_argument('--simular', action='store_true', help='Validar sin escribir cambios')
    args = parser.parse_args()
    try:
        written, duplicated, omitted, fields = importar(args.geojson, args.tipo, args.db,
                                                           args.nombre, args.alcaldia, args.simular)
        print(f'Campos detectados: {", ".join(fields)}')
        print(f'{"Importables" if args.simular else "Importados"}: {written}; duplicados: {duplicated}; omitidos por campos/coordenadas: {omitted}')
        if omitted:
            print('NOTA: usa --nombre/--alcaldia según los campos anteriores; no se inventan datos incompletos.')
    except (ValueError, OSError, sqlite3.Error, json.JSONDecodeError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        raise SystemExit(1)
