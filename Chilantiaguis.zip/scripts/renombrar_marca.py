"""Nombre comercial ya actualizado. NO cambia variables API ni archivos de base de datos.
Los nombres internos históricos se conservan por compatibilidad.
"""
print('Marca Chilantianguis ya actualizada: no hay cambios necesarios.')
