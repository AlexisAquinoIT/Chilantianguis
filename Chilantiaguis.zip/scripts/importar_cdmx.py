"""Obtiene y carga datos abiertos de SEDECO (tianguis y mercados) en SQLite.

Desde la raíz de Chilantiaguis:
  python scripts/importar_cdmx.py
  python scripts/importar_cdmx.py --tipo tianguis
  python scripts/importar_cdmx.py --tianguis mi_archivo.geojson --mercados otro.geojson

Descarga archivos desde los recursos registrados en el catálogo CKAN de CDMX.
Los datos originales pueden ser antiguos; NO les asigna horarios ni productos.
La descarga utiliza internet exclusivamente al ejecutar este comando.
"""
import argparse
import json
import sys
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
from importar_geojson import importar

PACKAGES = {
    'tianguis': 'tianguis-de-la-ciudad-de-mexico',
    'mercado': 'mercados-publicos',
}
# Algunos espejos del portal redirigen al dominio con www.
CKAN_ENDPOINTS = [
    'https://datos.cdmx.gob.mx/api/3/action/package_show',
    'https://www.datos.cdmx.gob.mx/api/3/action/package_show',
]

def get_json(url, limit=12_000_000):
    parsed=urlparse(url)
    if parsed.scheme != 'https':
        raise ValueError('Se requiere una URL HTTPS para descargar los datos.')
    req=Request(url, headers={'User-Agent':'Chilantiaguis-Hackaton/0.2 (importador público CKAN)', 'Accept':'application/json,application/geo+json,*/*'})
    with urlopen(req, timeout=28) as response:
        content=response.read(limit+1)
    if len(content)>limit:
        raise ValueError('Archivo más grande de lo permitido (12 MB).')
    return json.loads(content.decode('utf-8-sig'))

def official_resource(tipo):
    errors=[]
    for endpoint in CKAN_ENDPOINTS:
        try:
            data=get_json(endpoint+'?'+urlencode({'id':PACKAGES[tipo]}))
            if not data.get('success'):
                raise ValueError('Respuesta CKAN sin éxito')
            matches=[r for r in data['result']['resources'] if r.get('format','').lower() in ('geojson','geo json')]
            if not matches:
                raise ValueError('El catálogo no ofrece un recurso GeoJSON')
            matches.sort(key=lambda r:r.get('last_modified') or r.get('created') or '',reverse=True)
            url=matches[0].get('url','')
            # Solo URL HTTPS en el catálogo oficial; puede redirigir a una CDN.
            if urlparse(url).scheme!='https':
                raise ValueError('El recurso oficial no tiene URL HTTPS')
            return url
        except (HTTPError, URLError, ValueError, KeyError, TimeoutError, json.JSONDecodeError) as e:
            errors.append(str(e))
    raise ValueError('No pude consultar el catálogo CKAN: '+'; '.join(errors))

def main():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--tipo', choices=['tianguis','mercado'],help='Importar un único tipo (por defecto ambos)')
    p.add_argument('--tianguis',type=Path,help='Archivo GeoJSON de tianguis descargado manualmente')
    p.add_argument('--mercados',type=Path,help='Archivo GeoJSON de mercados descargado manualmente')
    p.add_argument('--db',type=Path,default=ROOT/'instance'/'chilantiaguis.sqlite3')
    opts=p.parse_args()
    if not opts.db.exists():
        print('ERROR: inicia Flask al menos una vez para crear la base de datos antes de importar.',file=sys.stderr)
        return 1
    kind=[opts.tipo] if opts.tipo else ['tianguis','mercado']
    total=0
    for tipo in kind:
        try:
            local=opts.tianguis if tipo=='tianguis' else opts.mercados
            if local:
                geo=local
            else:
                url=official_resource(tipo)
                print(f'Descargando {tipo} desde el catálogo de datos abiertos CDMX…')
                content=get_json(url)
                if content.get('type')!='FeatureCollection':
                    raise ValueError('El recurso descargado no es un GeoJSON FeatureCollection')
                geo=ROOT/'instance'/f'sedeco_{tipo}.geojson'
                geo.parent.mkdir(exist_ok=True)
                geo.write_text(json.dumps(content,ensure_ascii=False),encoding='utf-8')
            added, duplicates, invalid, fields=importar(geo,tipo,opts.db)
            total+=added
            print(f'{tipo}: {added} importados, {duplicates} ya existían, {invalid} incompletos.')
            if invalid:print(f'  Campos de origen: {", ".join(fields)}')
        except (ValueError,OSError,HTTPError,URLError,json.JSONDecodeError) as exc:
            print(f'No se pudo importar {tipo}: {exc}',file=sys.stderr)
            print('Descarga el GeoJSON manualmente en datos.cdmx.gob.mx y prueba --tianguis / --mercados.',file=sys.stderr)
    print(f'Terminó la importación: {total} registros nuevos. Los horarios y precios no se inventan.')
    return 0 if total else 1

if __name__=='__main__':
    raise SystemExit(main())
